﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Drawing.Imaging;
using System.Drawing;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\documents and settings\dac.dypm\my documents\visual studio 2010\Projects\WebApplication1\WebApplication1\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");

            SqlCommand command;

            try
            {
                string sql = "SELECT Img FROM Test WHERE No=1";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                command = new SqlCommand(sql, conn);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    byte[] img = (byte[])(reader[0]);
                    System.Drawing.Image image = byteArrayToImage(img);
                    string path = "saved.jpg";
                    image.Save(Server.MapPath("saved.jpg"));
                    Image1.ImageUrl = path;
                }
                
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                
            }
        }

        public System.Drawing.Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            System.Drawing.Image returnImage = System.Drawing.Image.FromStream(ms);
            return returnImage;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\documents and settings\dac.dypm\my documents\visual studio 2010\Projects\WebApplication1\WebApplication1\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");

            SqlCommand command;

            string picLoc = "Ascent.jpg";
            try
            {
                byte[] img = null;
                FileStream fs = new FileStream(Server.MapPath(picLoc), FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                img = br.ReadBytes((int)fs.Length);
                string sql = "INSERT INTO Test VALUES(1" + ",@IMG)";
                if (conn.State != ConnectionState.Open)
                    conn.Open();
                command = new SqlCommand(sql, conn);
                command.Parameters.Add(new SqlParameter("@IMG", img));
                int x = command.ExecuteNonQuery();
                conn.Close();
                Response.Write("Done!");
            }
            catch (Exception ex)
            {
                conn.Close();
            }
        }

      
    }
}
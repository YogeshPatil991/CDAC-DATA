﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace _004_Test_Sort_Culture
{

    #region Before Lock

    //class ThreadTest
    //{
    //    static bool done; // Static fields are shared between all threads
    //    static void Main()
    //    {
    //        new Thread(Go).Start();
    //        Go();
    //        Console.ReadLine();
    //    }
    //    //static void Go()
    //    //{
    //    //    if (!done) { done = true; Console.WriteLine("Done"); }
    //    //}
    //    static void Go()
    //    {
    //        if (!done) { Console.WriteLine("Done"); done = true; }
    //    }
    //} 
    #endregion

    #region After Lock
    //class ThreadSafe
    //{
    //    static bool done;
    //    static readonly object locker = new object();
    //    static void Main()
    //    {
    //        new Thread(Go).Start();
    //        Go();
    //        Console.ReadLine();
    //    }
    //    //static object i = 100;

    //    static void Go()
    //    {
    //        lock (locker)
    //        {
    //            if (!done) { Console.WriteLine("Done"); done = true; }
    //        }
    //    }
    //} 
    #endregion

    #region Mutex


    //class OneAtATimePlease
    //{
    //    static void Main()
    //    {
    //        using (var mutex = new Mutex(false, "MyMutexProgram"))
    //        {
    //            if (!mutex.WaitOne(10000))
    //            {
    //                return;
    //            }
    //            RunProgram();

    //            mutex.ReleaseMutex();
    //        }
    //    }
    //    static void RunProgram()
    //    {
    //        Console.WriteLine("Running. Press Enter to exit");
    //        Console.ReadLine();
    //    }
    //}


    #endregion

    #region Semaphore
    //class Demo 
    //{
    //    static SemaphoreSlim _sem = new SemaphoreSlim(1); // Capacity of 3
    //    static void Main()
    //    {
    //        for (int i = 1; i <= 5; i++) new Thread(Enter).Start(i);
    //        Console.ReadLine();
    //    }
    //    static void Enter(object id)
    //    {
    //        Console.WriteLine(id + " wants to enter");
    //        _sem.Wait();
    //        Console.WriteLine(id + " is in!"); // Only three threads
    //        Thread.Sleep(1000 * (int)id); // can be here at
    //        Console.WriteLine(id + " is leaving"); // a time.
    //        _sem.Release();
    //    }
    //}
    #endregion

    class BasicWaitHandle
    {
        static EventWaitHandle _waitHandle = new AutoResetEvent(false);

        static void Main()
        {
            new Thread(Waiter).Start();

            Console.WriteLine("Waiting for Child Thread to finish");
            Thread.Sleep(10000);                  // Pause for a second...
            _waitHandle.WaitOne();                // Wait for notification
            Console.WriteLine("Looks like child is done!");
            Console.WriteLine("Terminating ... hit enter!");
            Console.ReadLine();
        }

        static void Waiter()
        {
            Console.WriteLine("Starting the task");
            Thread.Sleep(2000);
            Console.WriteLine("Raising Notification!!");
            _waitHandle.Set();                    // Wake up the Waiter.
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test_DynamicType
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //Following code will compile but at runtime throw an error
            //Here runtime will try to find type of d (at runtime!!) using reflection
            //& will call the method Foo () if exists .. but since it does not exist
            //with the type d in the this sample .. we will get runtime Binder Exception!!
            //This is actually meant with the COM object .. Office development
            //So, instead of using reflection one can start using the method & 
            //call the methods .. runtime will use reflection in turn to find the 
            //method & call to it.... Its a late binding concept

            //So, if seen from the Reflector tool then Dynamic Language Runtime actually finds the
            //class of the object & then calls the method .. which can be varified from the 
            //Reflector utility

            //dynamic d = 3;
            //d.Foo();

            //Another Example ----
            dynamic d = GetSomeKick(0);
            Console.WriteLine(d.getkick());

            d = 10;
            Console.WriteLine(d.GetType().ToString());
            Console.ReadLine();

            //Ends Here ------
        }

        public static object GetSomeKick(int i)
        {
            if (i == 0)
            {
                return new HotDrink();
            }
            else
            {
                return new SoftDrink();
            }
        }
    }


    public class HotDrink
    {
        public string getkick()
        {
            return "Coffee";
        }
    }
    public class SoftDrink
    {
        public string getkick() //function may be returning different value
        {
            return "Coke";
        }
    }
}

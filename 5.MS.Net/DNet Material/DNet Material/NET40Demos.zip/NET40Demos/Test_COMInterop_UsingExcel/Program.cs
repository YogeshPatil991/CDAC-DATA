﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Test_COMInterop_UsingExcel
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var excel = new Microsoft.Office.Interop.Excel.Application();
                excel.Visible = true;
                excel.Workbooks.Add();
                excel.Cells[1, 1].Value = "Process Name";
                excel.Cells[1, 2].Value = "Memory Usage";

                var processes = Process.GetProcesses();

                int i = 2;
                foreach (var p in processes)
                {
                    excel.Cells[i, 1].Value = p.ProcessName;
                    excel.Cells[i, 2].Value = p.WorkingSet64;
                    i++;
                }

                //excel.Save("Test_COMInterop_UsingExcel.xls");
                Console.WriteLine("Excel Sheet Saved Successfully ..!!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}

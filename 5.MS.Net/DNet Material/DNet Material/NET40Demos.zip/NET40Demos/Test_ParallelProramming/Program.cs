﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

#region Basic

//class Program
//{
//    static void Main()
//    {
//        Tree tr = Tree.CreateSomeTree(3, 1);
//        Stopwatch sw = Stopwatch.StartNew();
//        WalkTree(tr);
//        Console.WriteLine("Elapsed= " + sw.ElapsedMilliseconds.ToString());
//        Console.ReadLine();
//    }

//    static void WalkTree(Tree tree)
//    {
//        if (tree == null) return;

//        WalkTree(tree.Left);
//        WalkTree(tree.Righ);
//        ProcessItem(tree.Data);
//    }

//    static int ProcessItem(int treeData)
//    {
//        // TODO something real with data
//        int j = 0;
//        for (int i = 0; i < 40000000; i++)
//            j++; // for demo purposes

//        return treeData; // not being used
//    }
//}

#endregion

#region Intermidiate
//class Program
//{
//    static void Main()
//    {
//        Tree tr = Tree.CreateSomeTree(3, 1);

//        Stopwatch sw = Stopwatch.StartNew();
//        WalkTree(tr);
//        Console.WriteLine("Elapsed= " + sw.ElapsedMilliseconds.ToString());

//        Console.ReadLine();
//    }

//    static void WalkTree(Tree tree)
//    {
//        if (tree == null) return;

//        Thread left = new Thread(() => WalkTree(tree.Left));
//        left.Start();
//        Thread righ = new Thread(() => WalkTree(tree.Righ));
//        righ.Start();

//        left.Join();
//        righ.Join();

//        ProcessItem(tree.Data);
//    }

//    static int ProcessItem(int treeData)
//    {
//        // TODO something real with data
//        int j = 0;
//        for (int i = 0; i < 40000000; i++)
//            j++; // for demo purposes

//        return treeData; // not being used
//    }
//}
#endregion

#region Advanced
class Program
{
    static void Main()
    {
        Tree tr = Tree.CreateSomeTree(3, 1);

        Stopwatch sw = Stopwatch.StartNew();

        Task t = new Task(delegate { WalkTree(tr); });
        t.Start();
        t.Wait();
        

        //Task t = Task.Factory.StartNew(delegate { WalkTree(tr); });

        //t.ContinueWith((c) => Console.WriteLine("ended")); //after elapsed
        //t.Wait(1500);
        //t.Cancel();
        Console.WriteLine("Elapsed= " + sw.ElapsedMilliseconds.ToString());

        Console.ReadLine();
    }

    static void WalkTree(Tree tree)
    {
        if (tree == null) return;

        Task left = new Task(() => WalkTree(tree.Left),
                  TaskCreationOptions.AttachedToParent);
        left.Start();

        Task righ = new Task(() => WalkTree(tree.Righ),
                  TaskCreationOptions.AttachedToParent);
        righ.Start();

        Task.WaitAll(left, righ);

        ProcessItem(tree.Data);
    }

    static int ProcessItem(int treeData)
    {
        // TODO something real with data
        int j = 0;
        for (int i = 0; i < 40000000; i++)
            j++; // for demo purposes

        return treeData; // not being used
    }
}

#endregion

#region Expert

//class Program
//{
//    static void Main()
//    {
//        Tree tr = Tree.CreateSomeTree(3, 1);

//        Stopwatch sw = Stopwatch.StartNew();
//        int total = WalkTree(tr);
//        Console.WriteLine(total.ToString());
//        Console.WriteLine("Elapsed= " + sw.ElapsedMilliseconds.ToString());

//        Console.ReadLine();
//    }

//    //static int WalkTree(Tree tree)
//    //{
//    //  if (tree == null) return 0;

//    //  int left = WalkTree(tree.Left);
//    //  int righ = WalkTree(tree.Righ);

//    //  return ProcessItem(tree.Data) + left + righ;
//    //}
//    static int WalkTree(Tree tree)
//    {
//        if (tree == null) return 0;

//        Task<int> left = new Task<int>(() => WalkTree(tree.Left), TaskCreationOptions.RespectParentCancellation);
//        left.Start();
//        Task<int> righ = new Task<int>(() => WalkTree(tree.Righ), TaskCreationOptions.RespectParentCancellation);
//        righ.Start();
//        //Task.WaitAll(left,righ) .. not needed here 
//        return ProcessItem(tree.Data) + left.Result + righ.Result;
//    }

//    static int ProcessItem(int treeData)
//    {
//        // TODO something real with data
//        int j = 0;
//        for (int i = 0; i < 40000000; i++)
//            j++; // for demo purposes

//        return treeData;
//    }
//} 

#endregion


public class Tree
    {
      public Tree Left = null;
      public Tree Righ = null;

      public int Data = 0;

      //       1
      //   2       2
      // 3   3   3   3
      //4 4 4 4 4 4 4 4
      internal static Tree CreateSomeTree(int depth, int start)
      {
        Tree root = new Tree();
        root.Data = start;

        if (depth > 0)
        {
          root.Left = CreateSomeTree(depth - 1, start + 1);
          root.Righ = CreateSomeTree(depth - 1, start + 1);
        }
        return root;
      }
    }





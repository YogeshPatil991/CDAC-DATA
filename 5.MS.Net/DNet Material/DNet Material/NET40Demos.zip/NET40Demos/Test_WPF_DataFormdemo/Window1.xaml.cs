﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test_WPF_DataFormdemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Test_WPF_DataFormdemo.masterDataSet masterDataSet = ((Test_WPF_DataFormdemo.masterDataSet)(this.FindResource("masterDataSet")));
            // Load data into the table Customer. You can modify this code as needed.
            Test_WPF_DataFormdemo.masterDataSetTableAdapters.CustomerTableAdapter masterDataSetCustomerTableAdapter = new Test_WPF_DataFormdemo.masterDataSetTableAdapters.CustomerTableAdapter();
            masterDataSetCustomerTableAdapter.Fill(masterDataSet.Customer);
            System.Windows.Data.CollectionViewSource customerViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("customerViewSource")));
            customerViewSource.View.MoveCurrentToFirst();
            // Load data into the table Orders. You can modify this code as needed.
            Test_WPF_DataFormdemo.masterDataSetTableAdapters.OrdersTableAdapter masterDataSetOrdersTableAdapter = new Test_WPF_DataFormdemo.masterDataSetTableAdapters.OrdersTableAdapter();
            masterDataSetOrdersTableAdapter.Fill(masterDataSet.Orders);
            System.Windows.Data.CollectionViewSource customerOrdersViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("customerOrdersViewSource")));
            customerOrdersViewSource.View.MoveCurrentToFirst();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            int i = Convert.ToInt32(textBox1.Text);
            if (i>10)
            {

                throw new Exception("exception occured");
            }
        }
    }
}

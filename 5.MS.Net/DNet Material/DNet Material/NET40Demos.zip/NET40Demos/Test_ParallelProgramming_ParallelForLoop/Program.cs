﻿using System;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.Threading.Tasks;

namespace Test_ParallelProgramming_ParallelForLoop
{
    class Program
    {
        static void Main()
        {
            Stopwatch sw = Stopwatch.StartNew();
            DoIt();
            Console.WriteLine("Elapsed= " + sw.ElapsedMilliseconds.ToString());

            Console.ReadLine();
        }

        static string[] arr =
          Directory.GetFiles(
            @"C:\WINDOWS\Web\Wallpaper\", "*.jpg"); // Add 24 files here

        private static void DoIt()
        {
            //foreach (string ip in arr)
            //{
            //    string result = null;
            //    //if (ip.Contains("5"))
            //    //{
            //    //    result = ip;
            //    //    break;
            //    //}
            //    Program.SimulateProcessing();
            //    Console.WriteLine(ip + TID);
            //}

            Parallel.ForEach(arr, (string ip) =>
              {
                  Program.SimulateProcessing();
                  Console.WriteLine(ip + TID);
              }
            );


            //string result = null;

            //Parallel.ForEach(arr,
            //  (string ip, ParallelLoopState ps) =>
            //  {

            //      Program.SimulateProcessing();
            //      if (!ps.IsStopped)
            //          Console.WriteLine(ip + TID);
            //      if (ip.Contains("5"))
            //      {
            //         // result = ip;
            //          ps.Stop();
            //      }
            //  }
            //);

        }

        private static void SimulateProcessing()
        {
            int j = 0;
            for (int i = 0; i < 10000000; i++)
            {
                j++;
            }
        }

        private static string TID
        {
            get
            {
                return " TID = " +
                  Thread.CurrentThread.
                  ManagedThreadId.ToString();
            }
        }
    }

    // Step 1. parallelize existing
    //Parallel.ForEach(arr,
    //  (string ip) =>
    //  {
    //    Program.SimulateProcessing();
    //    Console.WriteLine(ip + TID);
    //  }
    //);

    // Step2. make sequential a bit more complex and run
    //string result = null;

    //if (ip.Contains("Tree"))
    //{
    //  result = ip;
    //  break;
    //}

    // Step 3. parallelize the more complex scenario
    //Parallel.ForEach(arr,
    //  (string ip, ParallelLoopState ps) =>
    //  {
    //    Program.SimulateProcessing();
    //    if (!ps.IsStopped) Console.WriteLine(ip + TID);
    //    if (ip.Contains("Tree"))
    //    {
    //      result = ip;          
    //      ps.Stop();
    //    }
    //  }
    //);
}

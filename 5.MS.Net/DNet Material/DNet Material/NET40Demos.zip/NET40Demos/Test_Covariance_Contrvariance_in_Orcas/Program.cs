﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test_Covariance_Contrvariance_in_Orcas
{
    class Program
    {
         //Below is for contra Variance ... used in the demo later
         //In below line "in" is a keyword which is not supported in framework 3.5  
         //delegate void Action1<in T>(T a);   //This won't compile so .. no demo for contra variance in framework 3.5

        static void Main(string[] args)
        {
            //Co - Variance Demo

            //This demo is targetting to Framework 3.5
            //Here same solution code which is part of Test_Covariance_Contravariance
            //demo; will not work as following 3-4 lines of code was not possible in
            //framework 3.5 & there was a need of explicit type casting as given in 
            //non commented lines

            //IEnumerable<Animal> ListAnimals =
            //    new List<Tiger>() {
            //        new Tiger{ TigerColor="Yellow", AnimalCategory="ManEater", Veg_NonVeg="NonVeg"},
            //        new Tiger{ TigerColor="White", AnimalCategory="AnimalEater", Veg_NonVeg="NonVeg"},
            //                      };

            IEnumerable<Animal> ListAnimals =
              new List<Tiger>() {
                    new Tiger{ TigerColor="Yellow", AnimalCategory="ManEater", Veg_NonVeg="NonVeg"},
                    new Tiger{ TigerColor="White", AnimalCategory="AnimalEater", Veg_NonVeg="NonVeg"},
                                  }.Cast<Animal>(); //Here is the Type casting needed  in Framework 3.5


            foreach (Animal animal in ListAnimals)
            {
                Console.WriteLine("Category = {0}, Veg-NonVeg = {1}", animal.AnimalCategory, animal.Veg_NonVeg);
            }
            Console.ReadLine();

            //Contra Variance Demo

            //Below delegate is pointing to a method which is taking parameter of type animal
            //Action1<Animal> act1 = (ani) => { Console.WriteLine(ani.AnimalCategory); };
            
            //Below delegate is poing to above one
            //Action1<Tiger> cat1 = act1;
            
            //call to the second delegate which takes Tiger as parameter & in turn calls to
            //another delegate which passes Tiger Where Animal is expected!!
            //So implicit type casting happens here .. this works in case of 
            //lambda expression since using lambda we need not know the parameter to be passed at design time!!
            //See the old demo of lambada expression ... sorting demo!!

            //cat1(new Tiger() { AnimalCategory = "Neutral" });
            
            Console.Read();

        }
    }



    public class Animal
    {
        public string AnimalCategory { get; set; }
        public string Veg_NonVeg { get; set; }

    }

    public class Tiger : Animal
    {
        public string TigerColor { get; set; }
    }

    public class Deer : Animal
    {
        public string ForestName { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test_OptionalParameters
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();

            //One can call GetPersonInformation()  like
            person.GetPersonInformation(100);
            //One can call the method by passing optional parameter in any sequence like
            person.GetPersonInformation(200, paddress: "Pune", pname: "TechDays");
            //Like above .. if the method takes all parameters as optional parameters 
            //then any parameter can be passed in any sequence .. one can pass only some of the 
            //optional parameters like:
            person.GetPersonInformation(300, paddress: "Mumbai");
            
            //If seen from the reflector tool then actual method call for above methods given will be
            //In first case  : person.GetPersonInformation(100,"TechForge","Hydrabad");
            //In second case : person.GetPersonInformation(200,"TechDays","Pune");
            //In second case : person.GetPersonInformation(300,"TechForge","Mumbai");
            //So, Runtime actually gives a call to a method like usual method call
            //but programmer if free from calling method by passing parameters in sequence or so!

            Console.ReadLine();            
        }
    }

    public class Person
    {
        //Here in the method the optional parameters has to be specified after the declaration 
        //of all the required parameters .. if the required parameters are specified 
        //after the optional parameters then one will get the exception as ""Optional 
        //parameters must appear after all required parameters !!
        
        public void GetPersonInformation(int pid, string pname = "TechForge", string paddress="Hydrabad")
        {
            Console.WriteLine("PId = {0}, PName = {1} , PAddress= {2}",pid.ToString(), pname, paddress);
        }
    }


}

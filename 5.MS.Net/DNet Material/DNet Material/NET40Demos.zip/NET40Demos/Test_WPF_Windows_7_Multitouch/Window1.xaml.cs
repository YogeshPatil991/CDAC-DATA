﻿using System;
using System.Windows;
using Windows7.Multitouch;
using Windows7.Multitouch.Manipulation;
using Windows7.Multitouch.WPF;

namespace Test_WPF_Windows_7_Multitouch
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        // object of a .Net Wrapper class for processing multitouch manipulation
        private ManipulationProcessor manipulationProcessor = new ManipulationProcessor(ProcessorManipulations.ALL);
        private static bool IsMultitouchEnabled = TouchHandler.DigitizerCapabilities.IsMultiTouchReady;

        public Window1()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Window1_Loaded);
        }

        void Window1_Loaded(object sender, RoutedEventArgs re)
        {
            // check to see whether multitouch is enabled
            if (IsMultitouchEnabled)
            {
                // enables stylus events for processor manipulation
                Factory.EnableStylusEvents(this);

                // add the stylus events
                StylusDown += (s, e) => { manipulationProcessor.ProcessDown((uint)e.StylusDevice.Id, e.GetPosition(this).ToDrawingPointF()); };
                StylusUp += (s, e) => { manipulationProcessor.ProcessUp((uint)e.StylusDevice.Id, e.GetPosition(this).ToDrawingPointF()); };
                StylusMove += (s, e) => { manipulationProcessor.ProcessMove((uint)e.StylusDevice.Id, e.GetPosition(this).ToDrawingPointF()); };

                // register the ManipulationDelta event with the manipulation processor
                manipulationProcessor.ManipulationDelta += ProcessManipulationDelta;

                // set the rotation angle for single finger manipulation
                manipulationProcessor.PivotRadius = 2;
            }
        }

        private void ProcessManipulationDelta(object sender, ManipulationDeltaEventArgs e)
        {
            trTranslate.X += e.TranslationDelta.Width;
            trTranslate.Y += e.TranslationDelta.Height;

            trRotate.Angle += e.RotationDelta * 180 / Math.PI;

            trScale.ScaleX *= e.ScaleDelta;
            trScale.ScaleY *= e.ScaleDelta;
        }
    }
}

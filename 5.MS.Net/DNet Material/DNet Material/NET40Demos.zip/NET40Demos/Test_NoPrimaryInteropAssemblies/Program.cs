﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test_NoPrimaryInteropAssemblies
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Comment On PIA
            //Here in this program I have referred a COM based DLL
            //Which simply Adds two different integers..
            //Once the COM Based DLL is referred then after compilation there is a 
            //primary interop assembly created 
            //Then we can create object & use the methods or so ...
            //but along with the Actual Output one also has to deliver the 
            //Interop Assembly which is Created Automatically ...
            //In Framework 3.5 if you remove the Interop DLL then You will get an exception 
            //that DLL not found ... but in 4.0 Itwill not generate any DLL
            //Rather it will embed that assembly into the manifest & refer it from there
            //There is an option to even remove it from the manifest & have it behaved like 
            //earlier ... there is a checkbox embed interop assembly under project properties 
            //which is by default checked ..
            //Now After this .. even in 4.0 if we try to create a object of the Class1Class which 
            //is .. lets say kind of generated class .. we can't create object .. ratherwe get an exception 
            //so we need to create an object of Interface !!!! ... Here is the detailed exception report
            // & answer from Microsoft:

            //This issue is by design, and this error is returned 
            //when the PIA assembly is referenced with the new /l option and 
            //you new up a CoClass. (/l is applied when "Embed Interop Types" is true in 
            //the Properties window of the reference when selected in Solution Explorer. 
            //This is set to true by default.)
            //"Embed Interop Types" embeds the interfaces from the PIA 
            //into your assembly, and thus requires you to new up the interfaces directly.
            //I hope that helps, if you have any questions feel free to reactivate the bug.
            //Jonathan Aneja - Program Manager, VS Languages Team 

            //See the Example below which refers the Test_COM_BasedDLL from the folder where this 
            //solution is stored.. 
            #endregion

            //https://connect.microsoft.com/VisualStudio/feedback/ViewFeedback.aspx?FeedbackID=464158&wa=wsignin1.0
            
            try
            {
                Project1.Class1 PrimaryInteropAssemblyClassObject =
                       new Project1.Class1();
                short AdditionResult = PrimaryInteropAssemblyClassObject.Add(10, 20);
                Console.WriteLine(AdditionResult.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}

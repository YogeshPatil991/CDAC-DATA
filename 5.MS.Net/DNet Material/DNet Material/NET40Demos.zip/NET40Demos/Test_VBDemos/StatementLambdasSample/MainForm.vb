﻿Public Class MainForm

    Dim displaySamples As New SampleParser(New Samples(), My.Application.Info.DirectoryPath & "\..\..\Samples.vb")

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sampleList = displaySamples.GetSampleInfo()

        SamplesListBox.ValueMember = "ID"
        SamplesListBox.DisplayMember = "Description"
        SamplesListBox.DataSource = sampleList
    End Sub

    Private Sub CloseButton_Click() Handles CloseButton.Click
        Me.Close()
    End Sub

    Private Sub SamplesListBox_SelectedValueChanged() Handles SamplesListBox.SelectedValueChanged
        If Not String.IsNullOrEmpty(SamplesListBox.SelectedValue) Then _
            DisplayCodeRichTextBox.Text = CType(SamplesListBox.SelectedItem, SampleInfo).SampleText
    End Sub

    Private Sub RunTheCodeButton_Click() Handles RunTheCodeButton.Click
        If Not String.IsNullOrEmpty(SamplesListBox.SelectedValue) Then _
            DisplayResultsRichTextBox.Text =
                displaySamples.GetSampleResults(CType(SamplesListBox.SelectedItem, SampleInfo).MethodName,
                                                    Parameter1TextBox.Text, Parameter2TextBox.Text)
    End Sub

End Class




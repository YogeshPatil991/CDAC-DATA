﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DisplayCodeRichTextBox = New System.Windows.Forms.RichTextBox()
        Me.SamplesListBox = New System.Windows.Forms.ListBox()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.RunTheCodeButton = New System.Windows.Forms.Button()
        Me.DisplayResultsRichTextBox = New System.Windows.Forms.RichTextBox()
        Me.Parameter1TextBox = New System.Windows.Forms.TextBox()
        Me.Parameter1Label = New System.Windows.Forms.Label()
        Me.Parameter2Label = New System.Windows.Forms.Label()
        Me.Parameter2TextBox = New System.Windows.Forms.TextBox()
        Me.ResultsLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'DisplayCodeRichTextBox
        '
        Me.DisplayCodeRichTextBox.AccessibleName = "Display Code Rich Text Box"
        Me.DisplayCodeRichTextBox.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisplayCodeRichTextBox.ForeColor = System.Drawing.Color.DarkBlue
        Me.DisplayCodeRichTextBox.Location = New System.Drawing.Point(237, 12)
        Me.DisplayCodeRichTextBox.Name = "DisplayCodeRichTextBox"
        Me.DisplayCodeRichTextBox.ReadOnly = True
        Me.DisplayCodeRichTextBox.Size = New System.Drawing.Size(586, 237)
        Me.DisplayCodeRichTextBox.TabIndex = 0
        Me.DisplayCodeRichTextBox.Text = ""
        '
        'SamplesListBox
        '
        Me.SamplesListBox.AccessibleName = "Samples List Box"
        Me.SamplesListBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SamplesListBox.FormattingEnabled = True
        Me.SamplesListBox.ItemHeight = 16
        Me.SamplesListBox.Location = New System.Drawing.Point(12, 12)
        Me.SamplesListBox.Name = "SamplesListBox"
        Me.SamplesListBox.Size = New System.Drawing.Size(219, 148)
        Me.SamplesListBox.TabIndex = 1
        '
        'CloseButton
        '
        Me.CloseButton.AccessibleName = "Close Button"
        Me.CloseButton.Location = New System.Drawing.Point(729, 441)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(94, 23)
        Me.CloseButton.TabIndex = 2
        Me.CloseButton.Text = "Close"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'RunTheCodeButton
        '
        Me.RunTheCodeButton.AccessibleName = "Run the Code Button"
        Me.RunTheCodeButton.Location = New System.Drawing.Point(44, 226)
        Me.RunTheCodeButton.Name = "RunTheCodeButton"
        Me.RunTheCodeButton.Size = New System.Drawing.Size(143, 23)
        Me.RunTheCodeButton.TabIndex = 3
        Me.RunTheCodeButton.Text = "Run the Code"
        Me.RunTheCodeButton.UseVisualStyleBackColor = True
        '
        'DisplayResultsRichTextBox
        '
        Me.DisplayResultsRichTextBox.AccessibleName = "Display Results Rich Text Box"
        Me.DisplayResultsRichTextBox.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisplayResultsRichTextBox.Location = New System.Drawing.Point(237, 278)
        Me.DisplayResultsRichTextBox.Name = "DisplayResultsRichTextBox"
        Me.DisplayResultsRichTextBox.ReadOnly = True
        Me.DisplayResultsRichTextBox.Size = New System.Drawing.Size(586, 157)
        Me.DisplayResultsRichTextBox.TabIndex = 4
        Me.DisplayResultsRichTextBox.Text = ""
        '
        'Parameter1TextBox
        '
        Me.Parameter1TextBox.AccessibleDescription = "Parameter 1 TextBox"
        Me.Parameter1TextBox.Location = New System.Drawing.Point(114, 167)
        Me.Parameter1TextBox.Name = "Parameter1TextBox"
        Me.Parameter1TextBox.Size = New System.Drawing.Size(73, 20)
        Me.Parameter1TextBox.TabIndex = 5
        '
        'Parameter1Label
        '
        Me.Parameter1Label.AccessibleName = "Parameter 1 Label"
        Me.Parameter1Label.AutoSize = True
        Me.Parameter1Label.Location = New System.Drawing.Point(44, 170)
        Me.Parameter1Label.Name = "Parameter1Label"
        Me.Parameter1Label.Size = New System.Drawing.Size(64, 13)
        Me.Parameter1Label.TabIndex = 6
        Me.Parameter1Label.Text = "Parameter 1"
        '
        'Parameter2Label
        '
        Me.Parameter2Label.AccessibleName = "Parameter 2 Label"
        Me.Parameter2Label.AutoSize = True
        Me.Parameter2Label.Location = New System.Drawing.Point(44, 196)
        Me.Parameter2Label.Name = "Parameter2Label"
        Me.Parameter2Label.Size = New System.Drawing.Size(64, 13)
        Me.Parameter2Label.TabIndex = 8
        Me.Parameter2Label.Text = "Parameter 2"
        '
        'Parameter2TextBox
        '
        Me.Parameter2TextBox.AccessibleDescription = "Parameter 2 TextBox"
        Me.Parameter2TextBox.Location = New System.Drawing.Point(114, 193)
        Me.Parameter2TextBox.Name = "Parameter2TextBox"
        Me.Parameter2TextBox.Size = New System.Drawing.Size(73, 20)
        Me.Parameter2TextBox.TabIndex = 7
        '
        'ResultsLabel
        '
        Me.ResultsLabel.AccessibleName = "Results Label"
        Me.ResultsLabel.AutoSize = True
        Me.ResultsLabel.Location = New System.Drawing.Point(234, 262)
        Me.ResultsLabel.Name = "ResultsLabel"
        Me.ResultsLabel.Size = New System.Drawing.Size(42, 13)
        Me.ResultsLabel.TabIndex = 9
        Me.ResultsLabel.Text = "Results"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(835, 476)
        Me.Controls.Add(Me.ResultsLabel)
        Me.Controls.Add(Me.Parameter2Label)
        Me.Controls.Add(Me.Parameter2TextBox)
        Me.Controls.Add(Me.Parameter1Label)
        Me.Controls.Add(Me.Parameter1TextBox)
        Me.Controls.Add(Me.DisplayResultsRichTextBox)
        Me.Controls.Add(Me.RunTheCodeButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.SamplesListBox)
        Me.Controls.Add(Me.DisplayCodeRichTextBox)
        Me.Name = "MainForm"
        Me.Text = "Statements in Lambda Expressions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DisplayCodeRichTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents SamplesListBox As System.Windows.Forms.ListBox
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents RunTheCodeButton As System.Windows.Forms.Button
    Friend WithEvents DisplayResultsRichTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents Parameter1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Parameter1Label As System.Windows.Forms.Label
    Friend WithEvents Parameter2Label As System.Windows.Forms.Label
    Friend WithEvents Parameter2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents ResultsLabel As System.Windows.Forms.Label

End Class

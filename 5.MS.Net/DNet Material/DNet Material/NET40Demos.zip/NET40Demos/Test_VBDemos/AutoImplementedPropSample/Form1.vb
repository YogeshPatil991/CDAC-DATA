﻿Public Class Form1

    Sub Form1_Load() Handles MyBase.Load
        Me.CustomerBindingSource.DataSource = Customer.GetCustomerList().ToList()
    End Sub

End Class

﻿Class CustomerExpanded

    ' This example defines a class identical to Customer in
    ' Customer_AutoImplemented.vb, except that the properties 
    ' are not auto-implemented.

    Private _name As String
    Property Name() As String
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

    Private _customerID As Integer? = -1
    Property CustomerID() As Integer?
        Get
            Return _customerID
        End Get
        Set(ByVal value As Integer?)
            _customerID = value
        End Set
    End Property

    Private _city As String
    Property City() As String
        Get
            Return _city
        End Get
        Set(ByVal value As String)
            _city = value
        End Set
    End Property

    Private _state As String
    Property State() As String
        Get
            Return _state
        End Get
        Set(ByVal value As String)
            _state = value
        End Set
    End Property


    ' GetCustomerList builds and returns a list of CustomerExpanded objects.
    ' Compare the GetCustomerList function in Customer_AutoImplemented.vb,
    ' which builds the same list using collection initializers.

    Shared Function GetCustomerList() As IEnumerable(Of CustomerExpanded)

        Dim custList As New System.Collections.Generic.List(Of CustomerExpanded)
        Dim cust1 As New CustomerExpanded With {.Name = "Adventure Works", _
                                                .CustomerID = 13302, _
                                                .City = "Louisville", _
                                                .State = "Kentucky"}
        Dim cust2 As New CustomerExpanded With {.Name = "Coho Winery", _
                                                .CustomerID = 38847, _
                                                .City = "Springfield", _
                                                .State = "Missouri"}
        Dim cust3 As New CustomerExpanded With {.Name = "Proseware, Inc.", _
                                                .CustomerID = 19724, _
                                                .City = "Los Angeles", _
                                                .State = "California"}
        Dim cust4 As New CustomerExpanded With {.Name = "Fourth Coffee", _
                                                .CustomerID = 60442, _
                                                .City = "Honolulu", _
                                                .State = "Hawaii"}
        Dim cust5 As New CustomerExpanded With {.Name = "Margie's Travel", _
                                                .CustomerID = 67420, _
                                                .City = "Redmond", _
                                                .State = "Washington"}
        Dim cust6 As New CustomerExpanded With {.Name = "Wingtip Toys", _
                                                .CustomerID = 39871, _
                                                .City = "Springfield", _
                                                .State = "Illinois"}
        Dim cust7 As New CustomerExpanded With {.Name = "City Power & Light", _
                                                .CustomerID = 74739, _
                                                .City = "Redmond", _
                                                .State = "Washington"}
        Dim cust8 As New CustomerExpanded With {.Name = "Lucerne Publishing", _
                                                .CustomerID = 55061, _
                                                .City = "Redmond", _
                                                .State = "Washington"}

        custList.Add(cust1)
        custList.Add(cust2)
        custList.Add(cust3)
        custList.Add(cust4)
        custList.Add(cust5)
        custList.Add(cust6)
        custList.Add(cust7)
        custList.Add(cust8)

        Return custList

    End Function

End Class




﻿' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class Customer
    Public Property Id As Integer
    Public Property Name As String
    Public Property Orders As OrderCollection

    Public Sub New(ByVal id As Integer, ByVal name As String)
        Me.Id = id
        Me.Name = name
    End Sub

    Public Sub New(ByVal id As Integer, ByVal name As String, ByVal orders As OrderCollection)
        Me.Id = id
        Me.Name = name
        Me.Orders = orders
    End Sub

    Public Overrides Function ToString() As String
        ' Normally ToString returns the fully qualified typename. Instead, ToString is overridden
        ' to return a simple display string when added to a list box.
        Return String.Format("Id={0}, Name={1}", Me.Id, Me.Name)
    End Function
End Class


﻿' Copyright (c) Microsoft Corporation. All rights reserved.
Imports System.Runtime.CompilerServices

Module GenericAdd

    ' These extension methods enable you to use short syntax when adding custom
    ' objects to a collection using collection initializers. For example: 
    '
    '   Sub Add(ByVal genericList As List(Of Customer), ByVal id As Integer, ByVal name As String) 
    ' 
    ' The previous extension method enables you to specify a List(Of Customer) and supply 
    ' collection initializer syntax for each Customer object added as shown here:
    '
    '  Dim customers = New List(Of Customer) {{1, "Customer1"}, {2, "Customer2"}}
    '


    ' Add a Customer object to a generic List.
    <Extension()> _
    Sub Add(ByVal genericList As List(Of Customer), ByVal id As Integer, ByVal name As String)
        genericList.Add(New Customer(id, name))
    End Sub

    ' Add a Customer object with Orders to a generic List.
    <Extension()> _
    Sub Add(ByVal genericList As List(Of Customer), ByVal id As Integer,
                                                    ByVal name As String,
                                                    ByVal orders As OrderCollection)
        genericList.Add(New Customer(id, name, orders))
    End Sub
End Module

﻿' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class Order
    Public Property Id As Integer
    Public Property CustomerId As Integer
    Public Property OrderDate As DateTime

    Public Sub New(ByVal id As Integer,
                   ByVal customerId As Integer,
                   ByVal orderDate As DateTime)
        Me.Id = id
        Me.CustomerId = customerId
        Me.OrderDate = orderDate
    End Sub

    Public Overrides Function ToString() As String
        ' Normally ToString returns the fully qualified typename. Instead, ToString is overridden
        ' to return a simple display string when added to a list box.
        Return String.Format("Id={0}, CustomerID={1}, OrderDate={2}",
                             Me.Id, Me.CustomerId, Me.OrderDate.ToString("d"))
    End Function
End Class


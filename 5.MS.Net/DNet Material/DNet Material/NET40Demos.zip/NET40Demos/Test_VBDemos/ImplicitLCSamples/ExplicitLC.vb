﻿
Imports System.Reflection
Imports System.Runtime.CompilerServices

' The queries defined in this module use tradition line-continuation
' underscores. Compare these to the definitions in ImplicitLC.vb to 
' see the improvement with line continuations removed.

Module ExplicitLC

    Dim eol As String = vbCrLf

    Sub MethodQueryExplicit()
        Dim NameList = From method In _
                        (From type In Assembly.GetExecutingAssembly.GetTypes(), _
                              method2 In type.GetMembers() _
                         Where method2.MemberType = MemberTypes.Method AndAlso _
                               CType(method2, MethodInfo).IsStatic _
                         Select Item = CType(method2, MethodInfo) _
                         Order By Item.Name) _
                       Select method.Name _
                       Distinct

        Form1.ResultsTextBox.Text &= vbCrLf & "Method Query: " & vbCrLf
        For Each m In NameList
            Form1.ResultsTextBox.Text &= "  " & m & vbCrLf
        Next

    End Sub

    Sub CustomerQueryExplicit()

        Dim customerList = Customer.GetCustomerList

        Dim selectedCompanies = From cust In customerList _
                                Where cust.Name.StartsWith("C") And _
                                      cust.CustomerID > 30000 And _
                                      cust.City <> "Los Angeles" _
                                Select cust.CustomerID, cust.Name, _
                                       cust.State()

        Form1.ResultsTextBox.Text &= vbCrLf & "Customer Query: " & vbCrLf
        For Each selectedCo In selectedCompanies
            Form1.ResultsTextBox.Text &= "  " & selectedCo.Name & vbCrLf
        Next

    End Sub

    Sub MiscellaneousExamplesExplicit( _
        ByVal parameter1 As Integer, _
        ByVal parameter2 As String, _
        ByVal parameter3 As String _
        )
        Form1.ResultsTextBox.Text &= vbCrLf & "Miscellaneous Examples:" & vbCrLf

        Dim str As String = "Testing PrintIndented extension method."
        str.PrintIndented()
        eol.PrintIndented()

        ' If...Then...Else
        If (parameter1 = 0) Or _
           (parameter1 < 0) Then
            parameter2.PrintIndented()
        Else
            parameter3.PrintIndented()
        End If
        eol.PrintIndented()

        ' Object initializer
        Dim cust As New Customer With {.Name = "Blue Yonder Airlines", _
                                       .CustomerID = 25374, _
                                       .City = "Louisville", _
                                       .State = "Kentucky" _
                                      }
        cust.Name.PrintIndented()
        eol.PrintIndented()

        ' Arithmetic expression
        Dim answer = _
            3 + _
            8 - _
            6 + _
            12 * _
            2

        CStr(answer).PrintIndented()
        eol.PrintIndented()

    End Sub

    ' Attributes no longer require a line continuation.
    <Extension()> _
    Sub PrintIndented(ByVal s As String)
        Form1.ResultsTextBox.Text &= "  " & s
    End Sub

End Module

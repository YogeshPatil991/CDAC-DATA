﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Test_Covariance_Contravariance
{
    class Program
    {
      
        delegate void Action1<in T>(T a);
        
        static void Main(string[] args)
        {
            //Animal obj = new Tiger { AnimalCategory = "ManEater", TigerColor = "Yellow", Veg_NonVeg = "Both" };
            //Console.WriteLine(obj.AnimalCategory);

            

            Action1<Animal> act1 = (ani) => { Console.WriteLine(ani.AnimalCategory); };
            Action1<Tiger> cat1 = act1;
            cat1(new Tiger() { AnimalCategory = "Neutral", TigerColor = "Yellow" });
            Console.Read();
        }
    }



    public class Animal
    {
        public string AnimalCategory { get; set; }
        public string Veg_NonVeg { get; set; }

    }

    public class Tiger : Animal
    {
        public string TigerColor { get; set; }
    }

    public class Deer : Animal
    {
        public string ForestName { get; set; }
    }

}

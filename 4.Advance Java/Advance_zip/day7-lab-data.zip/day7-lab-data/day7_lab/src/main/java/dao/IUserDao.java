package dao;

import pojos.User;

public interface IUserDao {
//add a method to insert user details
	String registerUser(User newUser);
}

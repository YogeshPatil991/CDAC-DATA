package dao;

import pojos.User;
import static utils.HibernateUtils.getSf;
import org.hibernate.*;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User newUser) {
		String mesg = "User registration failed!!!!!!!!!";
		// 1. get SF from utils ---> open hib. session
		Session hibSession = getSf().openSession();// Getting s Session from SF : pools out a db conn , L1 cache is
													// created
		// 2. begin tx
		Transaction tx = hibSession.beginTransaction();
		try {
			// API of org.hibernate.Session : public Serializable save(Object
			// transientObject) throws HibernateExc
			hibSession.save(newUser); // transient ---> persistent
			// => success --> commit tx
			tx.commit(); // insert query will be fired
			mesg="User registered with ID "+newUser.getUserId();
		} catch (RuntimeException e) {
			// roll back tx
			if (tx != null)
				tx.rollback();
			// re throw the exc to caller
			throw e;
		} finally {
			// close session
			if (hibSession != null)
				hibSession.close();// L1 cache is destroyed , pooled out db cn rets to the pool
		}
		return mesg;
	}

}

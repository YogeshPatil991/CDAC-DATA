package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.CategoryDao;
import com.app.dao.ProductDao;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	//dep : DAO i/f : category dao
	@Autowired
	private CategoryDao categoryDao;
	//dep : Product dao
	@Autowired
	private ProductDao productDao;
	
	public CustomerController() {
		System.out.println("in ctor of "+getClass());
	}
	//add req handling method to forward the clnt to details page
	@GetMapping("/details")
	public String getDetails(Model map)
	{
		System.out.println("in get categories");
		//how to send categories to clnt ? 
		//invoke dao's method --> List --> scope ?
		map.addAttribute("all_categories", categoryDao.getAllCategories());
		return "/customer/details";//AVN : /WEB-INF/views/customer/details.jsp
	}
	//add req handling method to get all products under the chosen category
	@GetMapping("/products")
	public String getProducts(@RequestParam long catId,Model map)
	{
		System.out.println("in get products...");
		map.addAttribute("selected_products",productDao.getProductsByCategory(catId));
		return "/customer/products";
	}

}

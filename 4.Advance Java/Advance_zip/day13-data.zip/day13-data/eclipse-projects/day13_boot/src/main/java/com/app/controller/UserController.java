package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Role;
import com.app.pojos.User;
import com.app.service.UserService;

@Controller // mandatory !
@RequestMapping("/user")
public class UserController {
	// depepdency
	// Controller --dependent upon Service layer : for B.L

	@Autowired // autowire=byType
	private UserService userService;

	public UserController() {
		System.out.println("in ctor of " + getClass());
	}

//add req handling method for rendering login form
	@GetMapping("/login") // =@RequestMapping (method=GET)
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/user/login";// LVN --> D.S --> V.R : AVN : /WEB-INF/views/user/login.jsp
	}

	// add req hanling method to process login form
	@PostMapping("/login") // =@RequestMapping (method=POST)
	// how many rq params ? 2 : email n pass
	// @RequestParam : anno to bind req params --> method args
	// @RequestParam(name="pass") String pass123 : SC --> String
	// pass123=request.getParamter("pass");
	public String processLoginForm(@RequestParam String email, @RequestParam String pass, Model map,
			HttpSession session,RedirectAttributes flashMap) {
		System.out.println("in process login form " + email + " " + pass);
		try {
			// handler --> service --> dao : JPQL --> DB --> results
			User validatedUser = userService.authenticateUser(email, pass);
			flashMap.addFlashAttribute("mesg", "Login Successful!!!!");//mesg will be retained till NEXT req from the same clnt
			session.setAttribute("user_dtls", validatedUser);//dtls will be retained till invalidate/sess expires
			// role based authorization
			if (validatedUser.getRole() == Role.ADMIN) // => admin login
				return "redirect:/admin/categories";
			// valid login --> forward customer clnt to details(profile) page -->problem obs
			// : multiple submission issue
			// soln : replace Server Pull (forward) --> clnt pull (redirect + encoding) -->
			// sends temp resp --> clnt (skipping V.R n view layer)
			// clnt browser --> next request -->
			// http://host:port/day13_boot/customer/details --> D.S --> H.M
			return "redirect:/customer/details";// skips V.R n view layer

		} catch (RuntimeException e) {
			System.out.println("err in process login form " + e);
			// => invalid login ---> forward the clnt to login page
			map.addAttribute("mesg", "Invalid Login!!!!!!!!!!!!!!!!!!!"); //curnt req only !
			return "/user/login";// AVN : /WEB-INF/views/user/login.jsp

		}

	}

}

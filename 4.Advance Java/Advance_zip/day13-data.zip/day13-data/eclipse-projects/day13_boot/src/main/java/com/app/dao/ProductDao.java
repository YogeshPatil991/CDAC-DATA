package com.app.dao;

import java.util.List;

import com.app.pojos.Product;

public interface ProductDao {
//add a method to get the products by chosen category
	List<Product> getProductsByCategory(long categoryId);
}

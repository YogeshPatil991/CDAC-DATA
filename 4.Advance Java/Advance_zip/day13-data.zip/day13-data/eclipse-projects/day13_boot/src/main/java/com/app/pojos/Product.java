package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="products")
public class Product extends BaseEntity {
//productId, name ,price,description,inStock
	@Column(length = 20,unique = true)
	private String name;
	private double price;
	@Column(length = 200)
	private String description;
	@Column(name="in_stock")
	private boolean inStock;
	// how to access a category from Product ?
	//Product : many, child , owning
	@ManyToOne 
	@JoinColumn(name = "category_id" ,nullable = false ) //FK col name
	private Category productCategory;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(String name, double price, String description) {
		super();
		this.name = name;
		this.price = price;
		this.description = description;
		this.inStock = true;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isInStock() {
		return inStock;
	}

	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}

	public Category getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(Category productCategory) {
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Product ID "+getId()+"  [name=" + name + ", price=" + price + ", description=" + description + ", inStock=" + inStock
				+ "]";
	}
	
}

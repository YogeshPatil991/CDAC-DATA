package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.UserDao;
import com.app.pojos.User;

@Service //Mandatory , to tell SC , the following class contains B.L
@Transactional //Mandatory to tell SC to auto manage txs.
public class UserServiceImpl implements UserService {
	//dependncy : dao layer i/f
	@Autowired
	private UserDao userDao;

	@Override
	public User authenticateUser(String email, String password) {
		// TODO Auto-generated method stub
		return userDao.validateUser(email, password);
	}//service layer rets DETACHED User entity ---> controller

}

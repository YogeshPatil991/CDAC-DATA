package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="categories")
public class Category extends BaseEntity{
	//id,name,desc , products
	@Column(name="category_name",length = 30,unique = true)
	private String categoryName;
	@Column(length = 300)
	private  String description;
	//Category : one , parent , non owning(inverse)
	@OneToMany(mappedBy = "productCategory", cascade = CascadeType.ALL, orphanRemoval = true
	/* ,fetch = FetchType.EAGER */
																							 )
	private List<Product> products=new ArrayList<>();
	public Category() {
		// TODO Auto-generated constructor stub
	}
	public Category(String categoryName, String description) {
		super();
		this.categoryName = categoryName;
		this.description = description;
	}
	//setters n getters
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	//toString : DO NOT add any asso based fields in toString
	@Override
	public String toString() {
		return "Category Id "+getId()+" [categoryName=" + categoryName + ", description=" + description + "]";
	}
	public void addProduct(Product product) {
		//establish a link form product ---> category
		product.setProductCategory(this);
		//establish the link from category --> product
		products.add(product);
		
	}
	public void removeProduct(Product product)
	{
		//remove  a link form product ---> category
		product.setProductCategory(null);
		//remove  the link from category --> product
		products.remove(product);
	}
	

}

package com.app.dao;

import com.app.pojos.User;

public interface UserDao {
//add DAL (data access logic) method for user auth.
	User validateUser(String email,String pass);
}

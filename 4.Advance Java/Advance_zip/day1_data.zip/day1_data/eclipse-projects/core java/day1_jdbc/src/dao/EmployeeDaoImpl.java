package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojos.Employee;
import utils.DBUtils;
import static utils.DBUtils.*;

public class EmployeeDaoImpl implements IEmployeeDao {
	// state
	private Connection cn;
	private PreparedStatement pst1;

	// ctor which will be invoked once by the main class, in init phase of the app
	public EmployeeDaoImpl() throws SQLException {
		// get fixed conn from DBUtils
		cn = openConnection();
		// create PST to wrap select query
		pst1 = cn.prepareStatement("select * from my_emp where deptid=? and join_date>?");
		System.out.println("emp dao created!");
	}

	@Override
	public List<Employee> getEmpDetailsByDeptAndDate(String dept, Date date) throws SQLException {
		// 0. create empty AL
		List<Employee> empList = new ArrayList<>();
		// 1. set IN params
		pst1.setString(1, dept);
		pst1.setDate(2, date);
		//2. exec query
		try (ResultSet rst = pst1.executeQuery()) {
			// int empId, String name, String address, double salary, String deptId, Date
			// joinDate
			while (rst.next())
				empList.add(new Employee(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getDouble(4), dept,
						rst.getDate(6)));
		}
		return empList;
	}

	// add a non static method to clean up db resources
	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (cn != null)
			cn.close();
		System.out.println("emp dao cleaned up !");
	}

}

package pojos;

import java.sql.Date;

public class Employee {
//empid | name | addr  | salary | deptid | join_date
	private int empId;
	private String name;
	private String address;
	private double salary;
	private String deptId;
	private Date joinDate;
	//def ctor
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int empId, String name, String address, double salary, String deptId, Date joinDate) {
		super();
		this.empId = empId;
		this.name = name;
		this.address = address;
		this.salary = salary;
		this.deptId = deptId;
		this.joinDate = joinDate;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", address=" + address + ", salary=" + salary
				+ ", deptId=" + deptId + ", joinDate=" + joinDate + "]";
	}
	
	
}

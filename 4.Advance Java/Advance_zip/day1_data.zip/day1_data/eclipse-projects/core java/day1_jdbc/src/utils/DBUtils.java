package utils;

import java.sql.*;

public class DBUtils {
//add a static method to get FIXED db conn
	private static Connection connection;

	public static Connection openConnection() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/sunbeam_sep22?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true";
		connection = DriverManager.getConnection(url, "root", "root");
		return connection;
	}
	//add a static method to close the connection
	public static void closeConnection() throws SQLException
	{
		if(connection != null)
			connection.close();
	}
}

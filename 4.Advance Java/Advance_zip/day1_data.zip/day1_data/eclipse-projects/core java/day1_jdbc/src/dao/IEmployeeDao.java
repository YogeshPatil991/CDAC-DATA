package dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import pojos.Employee;

public interface IEmployeeDao {
//add a method declaration to get emp details by specific dept n joined after a date
	List<Employee> getEmpDetailsByDeptAndDate(String dept,Date date) throws SQLException;
}

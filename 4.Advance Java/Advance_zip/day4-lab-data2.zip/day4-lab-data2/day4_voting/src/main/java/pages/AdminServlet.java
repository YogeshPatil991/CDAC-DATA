package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CandidateDaoImpl;
import pojos.Candidate;
import pojos.User;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// set cont type
		response.setContentType("text/html");
		// pw
		try (PrintWriter pw = response.getWriter()) {
			// greet admin : by the name : get admin details from session scope
			// 1 get HttpSession from WC
			HttpSession session = request.getSession();
			// 2. get admin details
			User admin = (User) session.getAttribute("user_info");
			pw.print("<h3> Hello , " + admin.getName() + "</h3>");
			// get candidate dao's instance from session scope
			CandidateDaoImpl dao = (CandidateDaoImpl) session.getAttribute("candidate_dao");
			// invoke dao's method to get top 2 candidates
			List<Candidate> list = dao.getTop2CandidatesByVotes();
			pw.print("<h3>Top 2 Candidates By Votes </h3>");
			list.forEach(c -> pw.print("<h5> " + c + "</h5>"));
			// invoke dao's method
			pw.print("<h3> Partywise Analysis </h3>");
			Map<String, Integer> analysis = dao.getPartywiseVotesAnalysis();
			analysis.forEach((k, v) -> pw.print("<h5> Party" + k + " Votes : " + v + "</h5>"));

		} catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass(), e);
		}
	}

}

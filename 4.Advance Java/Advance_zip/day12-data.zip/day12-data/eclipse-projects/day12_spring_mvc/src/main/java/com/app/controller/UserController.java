package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/user")
public class UserController {
	public UserController() {
		System.out.println("in ctor of " + getClass());
	}

//add req handling method for : rendering the login form
	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/user/login";//handler rets LVN --> D.S --> V.R --> AVN : /WEB-INF/views/user/login.jsp
	}
	//add req handling method for : processing  login form
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email,@RequestParam String pass)
	{
		System.out.println("in process login form "+email+" "+pass);
		//Assume :login successful
		return "/user/details";//AVN : WEB-INF/views/user/details.jsp
	}
	
}

package com.app.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // mandatory
@RequestMapping("/check") // optional BUT reco for separation
public class CheckHandler {
	public CheckHandler() {
		System.out.println("in ctor of " + getClass());
	}

	// add request handling method to test model map
	@GetMapping("/test1") // do-get , can intercept GET method = @RequestMapping+method=GET
	public String testModelMap(Model map) {
		System.out.println("in test model map " + map);// {}
		// populate the map with 2 model attrs
		// API of o.s.ui.Model : public Model addAttribute(String attrName,Object
		// attrVal)
		map.addAttribute("server_ts", LocalDateTime.now()).addAttribute("number_list", List.of(10, 20, 30, 40, 50));
		return "/test/display";// Handler rets LVN ---> D.S (implicilty rets populated model map)
		// D.S ---> LVN ---> V.R ---> AVN : /WEB-INF/views/test/display.jsp --> D.S
		// chks for model attrs -- present -- 2 model attrs are saved under req scope
		// --> forwards the clnt to view layer
	}
}

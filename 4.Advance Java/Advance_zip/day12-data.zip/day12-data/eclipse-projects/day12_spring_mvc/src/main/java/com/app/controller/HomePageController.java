package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomePageController {
	public HomePageController() {
		System.out.println("in ctor of "+getClass());
	}
	//add a req handling method to render home(index page)
	@RequestMapping("/")
	public String renderHomePage()
	{
		System.out.println("in render home page..");
		return "/index";//Handler rets LVN --> D.S --> V.R : AVN : /WEB-INF/views/index.jsp --> D.S
		//chks for model attr s --absent --> rd.forward(rq,resp)
	}

}

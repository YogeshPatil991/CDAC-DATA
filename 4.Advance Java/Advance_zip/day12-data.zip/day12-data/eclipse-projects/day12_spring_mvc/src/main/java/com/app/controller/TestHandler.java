package com.app.controller;

import java.time.LocalDateTime;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller//MANDATORY cls level annotation to tell SC , following class is a req handling controller 
//singleton n eager spring bean
public class TestHandler {
	public TestHandler() {
		System.out.println("in ctor of "+getClass());
	}
	@PostConstruct
	public void myInit()
	{
		System.out.println("in init of "+getClass());
	}
	//add req handling method : to render welcome page
	@RequestMapping("/hello")
	public String sayHello()
	{
		System.out.println("in say hello");
		return "/welcome";//Handler rets logical(forward ) view name to D.S ---> V.R (view resolver) --> AVN
		//  /WEB-INF/views/welcome.jsp
	}
	//add req handling method to render dyn resp
	@RequestMapping("/hello2")
	public ModelAndView testModelAndView()
	{
		System.out.println("in test m n v");
		//API of ModelAndView(String logicalViewName,String modelAttributeName,Object modelAttrValue)
		return new ModelAndView("/welcome", "server_ts", LocalDateTime.now());
		//Handler ---> log view name + 1 model attr (ModelAndView) ---> D.S
		//D.S ---> log view name ---> V.R ---> AVN (/WEB-INF/views/welcome.jsp)  ---> D.S
		//D.S will add model attr/s under req scope(request.setAttribute("server_ts",ts) --> rd.forward -->
		//JSP --> EL 
	}

}

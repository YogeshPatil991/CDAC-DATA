package dao;

import pojos.Role;
import pojos.User;
import static utils.HibernateUtils.getSf;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.*;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User newUser) {
		// newUser : transient
		String mesg = "User registration failed!!!!!!!!!";
		// 1. get SF from utils ---> open hib. session
		Session hibSession = getSf().openSession();// Getting s Session from SF : pools out a db conn , L1 cache is
													// created
		Session hibSession2 = getSf().openSession();
		System.out.println(hibSession == hibSession2);// f
		System.out.println("session open " + hibSession.isOpen() + " connected " + hibSession.isConnected());// t t

		// 2. begin tx
		Transaction tx = hibSession.beginTransaction();
		try {
			// API of org.hibernate.Session : public Serializable save(Object
			// transientObject) throws HibernateExc
			hibSession.save(newUser); // transient ---> persistent
			// => success --> commit tx
			tx.commit(); // insert query will be fired
			System.out.println(
					"after commit : session open " + hibSession.isOpen() + " connected " + hibSession.isConnected());// t
																														// t

			mesg = "User registered with ID " + newUser.getUserId();
		} catch (RuntimeException e) {
			// roll back tx
			if (tx != null)
				tx.rollback();
			// re throw the exc to caller
			throw e;
		} finally {
			// close session
			if (hibSession != null)
				hibSession.close();// L1 cache is destroyed , pooled out db cn rets to the pool
		}
		System.out.println(
				"after finally : session open " + hibSession.isOpen() + " connected " + hibSession.isConnected());// t t

		return mesg;
	}

	@Override
	public String registerUserWithGetCurntSession(User newUser) {
		// newUser : TRANSIENT => not yet added to L1 cache , no rec in db , exists ONLY
		// in obj heap
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		Session session2 = getSf().getCurrentSession();
		System.out.println(session == session2);// t
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		System.out.println("session open " + session.isOpen() + " connected " + session.isConnected());// t t
		try {
			session.save(newUser);// newUser : PERSISTENT (part of L1 cache) , but not yet part of db
			tx.commit(); // hib performs auto dirty checking(session.flush() : synchs up state of L1
							// cache to DB) --insert query
			// session.close --> L1 cache destroyed , pooled out db cn rets to the pool
			System.out
					.println("after commit : session open " + session.isOpen() + " connected " + session.isConnected());// f
																														// f

		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();// no dirty chking(no session.flush()) , session.close => L1 cache destroyed ,
								// pooled out db cn rets to the pool
			System.out.println(
					"after rollback : session open " + session.isOpen() + " connected " + session.isConnected());// f f

			throw e;
		}
		// newUser : DETACHED (detached from L1 cache BUT not from DB)
		return "User registered with ID " + newUser.getUserId();
	}

	@Override
	public User getUserDetailsById(int userId) {
		User user = null;// user : NA
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// Session API : public <T> T get(Class<T> cls , Serializable id)

			user = session.get(User.class, userId);// int ---> Integer ---> Ser.
			// un comment to confirm L1 cache
//			user=session.get(User.class, userId);//int ---> Integer ---> Ser.
//			user=session.get(User.class, userId);//int ---> Integer ---> Ser.
//			user=session.get(User.class, userId);//int ---> Integer ---> Ser.
//			//user : procvided id exists : PERSISTENT
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return user;// user : DETACHED
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = null;
		String jpql = "select u from User u";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).getResultList();
//			users=session.createQuery(jpql, User.class).getResultList();
//			users=session.createQuery(jpql, User.class).getResultList();
//			//users : list of PERSISTENT entities
			tx.commit();// comment this out to understand the prob!!!!!!!!!!!!!!!!!!!!!!
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;// users : list of DETACHED entities
	}

	@Override
	public List<User> getUsersByDateAndRole(LocalDate start, LocalDate end, Role role) {
		List<User> users = null;
		String jpql = "select u from User u where u.regDate between :begin and :end1 and u.userRole=:rl";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("begin", start).setParameter("end1", end)
					.setParameter("rl", role).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;
	}

	@Override
	public List<String> getUserNamesByRole(Role userRole) {
		List<String> names = null;
		String jpql = "select u.name from User u where u.userRole = :role";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			names = session.createQuery(jpql, String.class).setParameter("role", userRole).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return names;
	}

	@Override
	public List<User> getUserDetailsByCtorExpr(Role userRole) {
		List<User> users = null;
		String jpql = "select new pojos.User(name,email,regAmount,regDate) from User u where u.userRole=:role";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("role", userRole).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;
	}

	@Override
	public String changePassword(String email, String oldPwd, String newPwd) {
		String mesg = "changing pwd failed!!!!!!!!!!!!!!!!";
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		User user = null;
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("em", email).setParameter("pass", oldPwd)
					.getSingleResult();
			// => valid user login
			// user : PERSISTENT
			user.setPassword(newPwd);// modifying state of the PERSISTENT entity
			tx.commit();// hib performs auto dirty chking : session.flush() --->update query --> session
						// closed
			mesg="Updated password!";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		// user : DETACHED from L1 cache
		user.setPassword("4567890");// If u change the state of detached entity : hib CAN NOT make the changes in
									// db!
		return mesg;
	}

}

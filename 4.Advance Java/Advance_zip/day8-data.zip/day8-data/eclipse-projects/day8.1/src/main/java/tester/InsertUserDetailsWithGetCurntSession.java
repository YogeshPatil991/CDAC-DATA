package tester;

import static utils.HibernateUtils.getSf;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;

public class InsertUserDetailsWithGetCurntSession {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			// create hib dao instance
			UserDaoImpl dao = new UserDaoImpl();
			System.out.println(
					"Enter user details : name,  email,  password,  confirmPassword,  userRole,  regAmount  regDate");
			// create user instance : transient
			User newUser = new User(sc.next(), sc.next(), sc.next(), sc.next(),
					Role.valueOf(sc.next().toUpperCase()),
					sc.nextDouble(), LocalDate.parse(sc.next()));
			System.out.println(dao.registerUserWithGetCurntSession(newUser));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

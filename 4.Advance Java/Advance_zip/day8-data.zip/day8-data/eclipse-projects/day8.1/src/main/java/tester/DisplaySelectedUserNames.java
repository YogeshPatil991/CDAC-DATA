package tester;

import static java.time.LocalDate.parse;
import static pojos.Role.valueOf;
import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.UserDaoImpl;

public class DisplaySelectedUserNames {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			// create hib dao instance
			UserDaoImpl dao = new UserDaoImpl();
			System.out.println("Enter  role");

			dao.getUserNamesByRole(valueOf(sc.next().toUpperCase()))
					.forEach(System.out::println);
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package dao;

import pojos.User;
import static utils.HibernateUtils.getSf;

import org.hibernate.*;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerNewUser(User transientUser) {
		String mesg="User registration Failed!!!!!!!!!!";
		// get session from SF
		Session session=getSf().getCurrentSession();
		//begin a tx
		Transaction tx=session.beginTransaction();
		try {
			session.persist(transientUser);
			tx.commit();//insert 
			mesg="User registered with ID "+transientUser.getUserId();
		} catch (HibernateException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}

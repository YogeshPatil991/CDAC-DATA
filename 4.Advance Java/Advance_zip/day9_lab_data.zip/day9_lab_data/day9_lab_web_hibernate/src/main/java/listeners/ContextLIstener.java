package listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import utils.HibernateUtils;

/**
 * Application Lifecycle Listener implementation class ContextLIstener
 *
 */
@WebListener
public class ContextLIstener implements ServletContextListener {

    

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
    	System.out.println("in ctx destroyed !");
    	 HibernateUtils.getSf().close();//clean up conn pool n release db resources
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
        System.out.println("in ctx inited");
        HibernateUtils.getSf();//class loading --> static init block --> singleton SF
    }
	
}

package beans;

import java.time.LocalDate;

import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;

public class UserBean {
	// props :
	private String name;
	private String email;
	private String password;
	private String confirmPass;
	private String role;
	private double regAmount;
	private String regDate;
	// dependency : user dao
	private UserDaoImpl userDao;

	public UserBean() {
		// dao instance
		userDao = new UserDaoImpl();
		System.out.println("user bean created!");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPass() {
		return confirmPass;
	}

	public void setConfirmPass(String confirmPass) {
		this.confirmPass = confirmPass;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public double getRegAmount() {
		return regAmount;
	}

	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public UserDaoImpl getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}

	// B.L method for user registration
	public String registerUser()
	{
		System.out.println("in reg user "+regAmount);
		//validate : pwd n confirm pwd must match
		if(password.equals(confirmPass))
		{
			//valid i/ps
			//create transient user 
			/*
			 * (String name, String email, String password, String confirmPassword, Role userRole, double regAmount,
			LocalDate regDate)
			 */
			User user=new User(name,email,password ,
					confirmPass,Role.valueOf(role.toUpperCase()),regAmount,LocalDate.parse(regDate));
			//call dao's method for persistence
			return userDao.registerNewUser(user);
		}
		return "Invalid Inputs !!!!!!!!!!!!! , Registration Failed!!!!!!!!!!!!!";
	}

}

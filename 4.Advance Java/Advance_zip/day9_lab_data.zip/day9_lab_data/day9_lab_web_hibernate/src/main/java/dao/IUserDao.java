package dao;

import pojos.User;

public interface IUserDao {
	String registerNewUser(User transientUser);
}

package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CandidateDaoImpl;
import dao.UserDaoImpl;
import pojos.User;

import static utils.DBUtils.*;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value = "/validate", loadOnStartup = 1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;
	private CandidateDaoImpl candidateDao;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	// overriding form of the method CAN NOT add any new checked excs
	public void init() throws ServletException {
		try {
			// 0. open db connection
			openConnection();
			// 1. create user dao instance
			userDao = new UserDaoImpl();
			//2. create candidate dao instance
			candidateDao=new CandidateDaoImpl();
		} catch (Exception e) {
			// e.printStackTrace();
			// how to inform the WC about failure of init ?
			// throw servlet exc
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			userDao.cleanUp();
			candidateDao.cleanUp();
			closeConnection();
		} catch (Exception e) {
			// throw new RuntimeException("err in destroy of "+getClass(), e);
			System.out.println("err in destroy " + getClass() + " exc " + e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set resp cont type
		response.setContentType("text/html");
		// 2 get PW
		try (PrintWriter pw = response.getWriter()) {
			// 3. read req params
			// API of ServletRequest i/f
			// public String getParamter(String paramName)
			String name = request.getParameter("nm");
			String password = request.getParameter("pass");
			// 4 . invoke dao's method for validation
			User validatedUser = userDao.validateUser(name, password);
			// null chking --null => invalid login : retry link --> login form
			if (validatedUser == null)
				pw.print("<h4>Invalid Login Please <a href='login.html'>Retry</a></h4>");// CP I
			else {
				// not null => successful login ,
				// auth successful ---> proceed to role based authorization
				// 1. Get HttpSession from WC
				// API of request : HtpSession getSession()
				HttpSession session = request.getSession();
				System.out.println("session is new " + session.isNew());// true
				System.out.println("Session ID " + session.getId());// uniquely generated string / clnt , created by WC
				// save validated user details under session scope
				// HttpSession method : public void setAttribute(String attrName,Object attVal)
				session.setAttribute("user_info", validatedUser);
				//store user dao instance under session scope
				session.setAttribute("user_dao", userDao);
				//store candidate dao instance under session scope
				session.setAttribute("candidate_dao", candidateDao);
				if (validatedUser.getRole().equals("admin"))
					// redirect user to admin page
					response.sendRedirect("admin");

				else // => voter logged in
				if (validatedUser.isStatus()) // => voter has alrdy voted
					// redirect to logout page
					response.sendRedirect("logout");
				else
					// redirect to candidate list page
					response.sendRedirect("candidate_list");
				// WC : sends temp redirect resp
				// SC 302 , headers: location:candidate_list , set-cookie : nm :JSESSIONID
				// value : dfhsfhgf56784686
				// body : EMPTY ---> clnt browser
				// clnt browser sends NEW request : URL : http://host:port/day3.2/candidate_list
				// method=GET

			}

		} catch (Exception e) {
			throw new ServletException("err in do-post  of " + getClass(), e);
		}
	}

}

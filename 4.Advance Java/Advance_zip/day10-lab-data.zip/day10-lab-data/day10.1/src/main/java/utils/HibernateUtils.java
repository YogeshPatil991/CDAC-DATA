package utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

//to create singleton , immutable SF instance
public class HibernateUtils {
	private static SessionFactory sf;
	static {
		System.out.println("in static init block");
		sf = new Configuration().configure().buildSessionFactory();
		System.out.println("SF created ....");
	}
	public static SessionFactory getSf() {
		return sf;
	}
	

}

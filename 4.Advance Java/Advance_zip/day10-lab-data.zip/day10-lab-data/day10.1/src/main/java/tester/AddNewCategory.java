package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import pojos.Category;

public class AddNewCategory {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			CategoryDaoImpl categoryDao = new CategoryDaoImpl();
			System.out.println("Enter category name ");
			String name = sc.nextLine();
			System.out.println("Enter desc on separate lines");
			String desc = sc.nextLine();
			Category cat=new Category(name, desc);
			System.out.println(categoryDao.addCategory(cat));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import dao.ProductDaoImpl;
import pojos.Category;
import pojos.Product;

public class DisplayCategoryAndProductDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			CategoryDaoImpl categoryDao = new CategoryDaoImpl();
			System.out.println("Enter category name");
			String name = sc.nextLine();
			Category category = categoryDao.getDetails(name);
			//category : DETACHED
			System.out.println("catgeroy details " + category);
			System.out.println("Product Details ");
			 category.getProducts().forEach(System.out::println); //un comment to see the
			// LazyInitExc => u are trying to access un fetched data : represented by a
			// proxy , outside the hib session scope : i.e entities are DETACHED state
		//	category.getProducts().forEach(p -> System.out.println(p.getClass()));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import dao.CustomerDaoImpl;
import pojos.Category;
import pojos.Customer;
import pojos.Role;

public class CustomerRegistration {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			CustomerDaoImpl custDao = new CustomerDaoImpl();
			System.out.println("Customer details pls : firstName,  lastName,  email,  password,  role");
			Customer customer = new Customer(sc.next(), sc.next(), sc.next(), sc.next(),
					Role.valueOf(sc.next().toUpperCase()));
			System.out.println(custDao.registerCustomer(customer));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

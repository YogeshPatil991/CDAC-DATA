package pojos;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.*;

@Entity
@Table(name = "carts")
public class Cart extends BaseEntity {
	private int quantity;
	@Column(name = "total_price")
	private double totalPrice;
	@Column(name = "created_on")
	private LocalDate createdOn;
	// Cart HAS-A Customer : uni dir asso between Cart 1----->1 Customer
	@OneToOne//def fetch type : EAGER => whenever you fetch cart details , Customer details will be fetched
	@JoinColumn(name="customer_id")//FK constraint
	private Customer cartOwner;
	// Cart HAS-A Products : uni dir asso between Cart *---->* Product
	@ManyToMany //mandatory : def fetch type : LAZY 
	@JoinTable(name="carts_products",
	joinColumns = @JoinColumn(name="cart_id"),
	inverseJoinColumns = @JoinColumn(name="product_id")) //OPTIONAL BUT RECO!
	private Set<Product> products = new HashSet<>();

	public Cart() {
		// TODO Auto-generated constructor stub
	}

	// all getters n setters
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public LocalDate getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}

	public Customer getCartOwner() {
		return cartOwner;
	}

	public void setCartOwner(Customer cartOwner) {
		this.cartOwner = cartOwner;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Cart ID " + getId() + " [quantity=" + quantity + ", totalPrice=" + totalPrice + ", createdOn="
				+ createdOn + "]";
	}

}

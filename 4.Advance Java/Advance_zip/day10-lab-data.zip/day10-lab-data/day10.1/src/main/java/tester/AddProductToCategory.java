package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.ProductDaoImpl;
import pojos.Product;

public class AddProductToCategory {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			ProductDaoImpl productDao=new ProductDaoImpl();
			System.out.println("Enter category id , for the new product");
			long categoryId=sc.nextLong();
			sc.nextLine();//to read new line
			System.out.println("Enter new product details : nm price desc , on separate lines");
			String name = sc.nextLine();
			double price=sc.nextDouble();
			sc.nextLine();//to read new line
			String desc = sc.nextLine();
			Product p=new Product(name, price, desc);			
			System.out.println(productDao.addProductToCategory(categoryId, p));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

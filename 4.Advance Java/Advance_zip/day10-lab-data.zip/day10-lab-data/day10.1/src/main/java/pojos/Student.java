package pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Student extends BaseEntity {
	private String name;
	private String email;
	private String password;
	// bi dir one-to-one asso
	@OneToOne(mappedBy = "myStudent") // mappedBy : to tell hib this side is inverse side of the asso : DO NOT create
										// FK
	private Address address;
	//add mapping between Entity  1---->* Collection of composite type Value Type
	@ElementCollection //Mandatory anno : to represent collection of embeddables
	@CollectionTable(name = "edu_qualifications" , joinColumns = @JoinColumn(name="student_id"))
	private List<Qualification> qualifications=new ArrayList<>();
	

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	

	public List<Qualification> getQualifications() {
		return qualifications;
	}

	public void setQualifications(List<Qualification> qualifications) {
		this.qualifications = qualifications;
	}

	@Override
	public String toString() {
		return "Student ID " + getId() + " [name=" + name + ", email=" + email + ", password=" + password + "]";
	}

}

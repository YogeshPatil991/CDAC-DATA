package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.ProductDaoImpl;
import pojos.Product;

public class GetProductDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			ProductDaoImpl productDao = new ProductDaoImpl();
			System.out.println("Enter product id , to fetch details");
			Product p=productDao.getDetails(sc.nextLong());
			System.out.println(p);//product dtls
		//	System.out.println("Product Category "+p.getProductCategory()); //cat dtls
			

		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

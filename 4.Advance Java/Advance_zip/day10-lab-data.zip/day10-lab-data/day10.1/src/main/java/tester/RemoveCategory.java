package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import dao.ProductDaoImpl;
import pojos.Product;

public class RemoveCategory {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			CategoryDaoImpl categoryDao=new CategoryDaoImpl();
			System.out.println("Enter category name");
			String name=sc.nextLine();
			System.out.println(categoryDao.removeCategory(name));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

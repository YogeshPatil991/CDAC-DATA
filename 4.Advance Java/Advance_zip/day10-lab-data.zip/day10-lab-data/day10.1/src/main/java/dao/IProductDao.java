package dao;

import pojos.Product;

public interface IProductDao {
	String addProductToCategory(long categoryId,Product product);
	Product getDetails(long productId);
}

package pojos;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass // to tell hibernate : that follow is a common super class for all entities ,
					// having no table asso with it
public class BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	// setter n getter

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}

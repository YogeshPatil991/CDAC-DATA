package tester;

import static utils.HibernateUtils.getSf;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import pojos.Category;
import pojos.Product;

public class AddNewCategoryWithProducts {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			CategoryDaoImpl categoryDao = new CategoryDaoImpl();
			System.out.println("Enter category name");
			String name = sc.nextLine();
			String desc = sc.nextLine();
			Category cat = new Category(name, desc);
			System.out.println("Add 1st product details : nm price desc");
			name = sc.nextLine();
			double price = sc.nextDouble();
			sc.nextLine();// to read new line
			desc = sc.nextLine();
			Product p1 = new Product(name, price, desc);
			// how to add this product to category ?
			cat.addProduct(p1);
			System.out.println("Add 2nd product details : nm price desc");
			name = sc.nextLine();
			price = sc.nextDouble();
			sc.nextLine();// to read new line
			desc = sc.nextLine();
			Product p2 = new Product(name, price, desc);
			// how to add this product to category ?
			cat.addProduct(p2);
			System.out.println(categoryDao.addCategory(cat));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="student_adr")
public class Address extends BaseEntity {
	@Column(name="adr_line1",length = 100)
	private String adrLine1;
	@Column(name="adr_line2",length = 100)
	private String adrLine2;
	@Column(length =20)
	private String city;
	@Column(name="zip_code",length = 10)
	private String zipCode;
	//add bi dir one-one asso between entities Student   1<------>1 Address
	@OneToOne //def fetch : EAGER
	@JoinColumn(name="student_id")
	private Student myStudent;
	public Address() {
		// TODO Auto-generated constructor stub
	}
	public String getAdrLine1() {
		return adrLine1;
	}
	public void setAdrLine1(String adrLine1) {
		this.adrLine1 = adrLine1;
	}
	public String getAdrLine2() {
		return adrLine2;
	}
	public void setAdrLine2(String adrLine2) {
		this.adrLine2 = adrLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public Student getMyStudent() {
		return myStudent;
	}
	public void setMyStudent(Student myStudent) {
		this.myStudent = myStudent;
	}
	@Override
	public String toString() {
		return "Address ID "+getId()+" [adrLine1=" + adrLine1 + ", adrLine2=" + adrLine2 + ", city=" + city + ", zipCode=" + zipCode
				+ "]";
	}
	

}

package dao;

import pojos.Category;
import pojos.Product;
import static utils.HibernateUtils.getSf;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProductDaoImpl implements IProductDao {

	@Override
	public String addProductToCategory(long categoryId, Product product) {
		String mesg = "Adding Product  Failed !!!!!!!!!!";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// how will you do it ?
			// get Category from it's id
			Category category = session.get(Category.class, categoryId);
			if (category != null) {
				// valid category
				category.addProduct(product);
				session.persist(product);
				mesg = "Added product to the category " + category.getCategoryName();
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public Product getDetails(long productId) {
		Product p=null;
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			p=session.get(Product.class, productId);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return p;
	}

}

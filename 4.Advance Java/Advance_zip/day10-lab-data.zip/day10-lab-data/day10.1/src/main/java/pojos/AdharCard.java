package pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable // to tell hib that following class DOES NOT have a standalone existence , it's
			// details are going to embedded in the OWNING entity
public class AdharCard {
	@Column(unique = true,name="card_no",length = 14)
	private String cardNo;
	@Column(length = 30)
	private String location;
	@Column(name="creation_date")
	private LocalDate creationDate;

	public AdharCard() {
		// TODO Auto-generated constructor stub
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	@Override
	public String toString() {
		return "AdharCard [cardNo=" + cardNo + ", location=" + location + ", creationDate=" + creationDate + "]";
	}

}

package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Customer;
import static utils.HibernateUtils.getSf;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public String registerCustomer(Customer transientCustomer) {
		String mesg = "Customer reg failed !!!!!!!!!!!!";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(transientCustomer);
			tx.commit();// insert
			mesg = "Registered new customer with ID " + transientCustomer.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}

package pojos;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable // to tell hib following class DOES NOT have stand alone existence . It's asso
			// with owning entity : Student
public class Qualification {
	@Enumerated(EnumType.STRING)
	@Column(name = "edu_type", length = 10)
	private EduType eduTYpe;
	private int year;
	private int marks;

	public Qualification() {
		// TODO Auto-generated constructor stub
	}

	public Qualification(EduType eduTYpe, int year, int marks) {
		super();
		this.eduTYpe = eduTYpe;
		this.year = year;
		this.marks = marks;
	}

	public EduType getEduTYpe() {
		return eduTYpe;
	}

	public void setEduTYpe(EduType eduTYpe) {
		this.eduTYpe = eduTYpe;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Qualification [eduTYpe=" + eduTYpe + ", year=" + year + ", marks=" + marks + "]";
	}

}

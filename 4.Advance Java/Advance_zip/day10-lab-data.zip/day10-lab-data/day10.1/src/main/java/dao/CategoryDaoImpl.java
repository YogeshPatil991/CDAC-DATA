package dao;

import static utils.HibernateUtils.getSf;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Category;
import pojos.Product;

public class CategoryDaoImpl implements ICategoryDao {

	@Override
	public String addCategory(Category newCategory) {
		String mesg = "Adding Category Failed !!!!!!!!!!";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(newCategory);
			tx.commit();
			mesg = "Category added with ID " + newCategory.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public Category getCategoryDetails(String categoryName) {
		Category category = null;
		String jpql = "select c from Category c where c.categoryName=:nm";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			category = session.createQuery(jpql, Category.class).setParameter("nm", categoryName).getSingleResult();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return category;
	}

	@Override
	public String removeCategory(String categoryName) {
		String mesg = "Removing Category Failed !!!!!!!!!!";
		String jpql = "select c from Category c where c.categoryName=:nm";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			Category category = session.createQuery(jpql, Category.class).setParameter("nm", categoryName)
					.getSingleResult();
			// => category : PERSISTENT
			session.delete(category);// category : REMOVED
			tx.commit();// delete query , category : TRANSIENT
			mesg = "Category along with products deleted !";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	public String removeProductFromCategory(long categoryId, long productId) {
		String mesg = "Removing a product from Category Failed !!!!!!!!!!";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// get category form it's id
			Category cat = session.get(Category.class, categoryId);
			// get product from it's id
			Product product = session.get(Product.class, productId);
			if (cat != null && product != null) {
				// helper method
				cat.removeProduct(product);
				mesg = "removed a product " + product.getName() + "from categroy " + cat.getCategoryName();
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public Category getDetails(String categoryName) {
		Category cat=null;
	//	String jpql="select c from Category c where c.categoryName=:nm";
		String jpql="select c from Category c  left outer join fetch c.products where c.categoryName=:nm";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			cat=session.createQuery(jpql, Category.class).
					setParameter("nm", categoryName).getSingleResult();
			//cat : PERSISTENT
			//Give a hint to hib to load the collection
			cat.getProducts().size();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return cat; //cat : DETACHED  from L1 cache
	}

}

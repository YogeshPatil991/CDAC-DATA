package dao;

import java.util.List;

import pojos.Category;

public interface ICategoryDao {
	String addCategory(Category newCategory);
	Category getCategoryDetails(String categoryName);
	String removeCategory(String categoryName);
	String removeProductFromCategory(long catId, long productId);
	Category getDetails(String categoryName);
}

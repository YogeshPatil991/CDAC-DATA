package pojos;

public enum EduType {
	SSC, HSC, DEGREE
}

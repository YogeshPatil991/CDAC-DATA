package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CandidateDaoImpl;
import dao.UserDaoImpl;
import pojos.User;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1 set cont type
		response.setContentType("text/html");
		// 2. get PW from response
		try (PrintWriter pw = response.getWriter()) {
			// 1. get HTTP session from WC
			HttpSession session = request.getSession();
			System.out.println("from logout : session is new " + session.isNew());// false : if cookies are accepted!
			System.out.println("session id " + session.getId());// same : if cookies are accepted
			// 2. get voter details ,
			User voter = (User) session.getAttribute("user_info");
			if (voter != null) {
				pw.print("<h4> Hello , "+voter.getName()+"</h4>");
				if (voter.isStatus()) {
					// alrdy voted !
					pw.print("<h4> You have already voted earlier , Can't vote again!!!!!!</h4>");

				} else {
					// voter has not yet voted
					// 3. get chosen candidate id from req
					int candidateId = Integer.parseInt(request.getParameter("candidate_id"));
					// get user dao , candidate dao from session scope
					UserDaoImpl userDao = (UserDaoImpl) session.getAttribute("user_dao");
					CandidateDaoImpl candidateDao = (CandidateDaoImpl) session.getAttribute("candidate_dao");
					//invoke voter dao's method to update voting status
					pw.print("<h5> "+userDao.updateVotingStatus(voter.getUserId())+"</h5>");
					//invoke candidate dao's method : to ince votes 
					pw.print("<h5>"+candidateDao.incrementVotes(candidateId)+"</h5>" );
				}
			} else
				pw.print("<h4> Session Tracking Failed : No Cookies !!!!!!!!!!! OR Session Expired !!!!</h4>");
			//invalidate Http Session
			session.invalidate();
			pw.print("<h4> You have logged out.....</h4>");			

		} catch (Exception e) {
			throw new ServletException("err in do-get of "+getClass(), e);
		}
	}

}

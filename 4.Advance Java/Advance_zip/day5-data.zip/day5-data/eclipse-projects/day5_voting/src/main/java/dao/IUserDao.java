package dao;

import java.sql.SQLException;

import pojos.User;

public interface IUserDao {
//add a method user validation
	User validateUser(String name,String password) throws SQLException;
	//add a method for changing voting status
	String updateVotingStatus(int voterId) throws SQLException;
	
}

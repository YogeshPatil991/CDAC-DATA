package dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import pojos.Candidate;

public interface ICandidateDao {
//add a method to get all candidate details
	List<Candidate> getAllCandidates() throws SQLException; 
	//add a method to inc votes for a chosen candidate
	String incrementVotes(int candidateId) throws SQLException; 
	//add a method to get details of top 2 candidates
	List<Candidate> getTop2CandidatesByVotes() throws SQLException;
	//add a method to ret party wise votes analysis
	Map<String,Integer> getPartywiseVotesAnalysis() throws SQLException;
	
}

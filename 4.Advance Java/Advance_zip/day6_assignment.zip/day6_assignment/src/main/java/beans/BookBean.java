package beans;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;

import dao.BookDaoImpl;
import pojos.Book;

public class BookBean {
//state 
	private String title;
	private String author;
	private String category;
	private double price;//WC will auto parse String ---> double
	private String pubDate;//JB will have to do parsing from string --> localdate
	//dendency : book dao
	private BookDaoImpl bookDao;
	//def ctor : will be invoked by WC : when JSP : <jsp:useBean>
	public BookBean() throws SQLException{
		// create dao instance
		bookDao=new BookDaoImpl();
		System.out.println("book bean created !");
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPubDate() {
		return pubDate;
	}
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}
	public BookDaoImpl getBookDao() {
		return bookDao;
	}
	public void setBookDao(BookDaoImpl bookDao) {
		this.bookDao = bookDao;
	}
	//Add B.L to validate pub date n if valid --invoke dao's method for inserting a new rec.
	//Will be invoked by JSP : using EL syntax.
	public String insertBookDetails() throws SQLException
	{
		System.out.println("in insert book "+price);//only for debugging!
		//parsing : String ---> LocalDate
		LocalDate publishDate=LocalDate.parse(pubDate);
		//book should not be too old ! , diff bet curnt date n pub date > 5 yrs : error !!!!!!!
		long years=Period.between(publishDate, LocalDate.now()).getYears();
		if(years > 5)
			return "Book Can't be added : Invalid Publish Date!!!!!!!!!!!";
		//=> valid date --< create book class instance then invoke dao's method
		Book book=new Book(title, author, category, price);
		return bookDao.addNewBook(book);
		
		
	}
	
	
	
	
	
}

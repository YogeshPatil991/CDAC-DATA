package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import pojos.Book;
import static utils.DBUtils.getConnection;

public class BookDaoImpl implements IBookDao {
	// state
	private Connection cn;
	private PreparedStatement pst1;

	// def ctor : will be called by layer above : BookBean (java bean)
	public BookDaoImpl() throws SQLException {
		// get cn from DBUtils
		cn = getConnection();
		pst1 = cn.prepareStatement("insert into books values(default,?,?,?,?)");
		System.out.println("Book dao created!");
	}

	@Override
	public String addNewBook(Book newBook) throws SQLException {
		//set IN params
		pst1.setString(1, newBook.getTitle());//title 
		pst1.setString(2, newBook.getAuthor());//author
		pst1.setString(3, newBook.getCategory());//category		
		pst1.setDouble(4,newBook.getPrice());//price
		//exec update : DML
		int updateCount=pst1.executeUpdate();
		if(updateCount == 1)
			return "Book details inserted successfully!";
		return "Insertion of book details failed!!!!!!!!!!!!!!!!!!";
					
	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		System.out.println("Book dao cleaned up");
	}

}

package dao;

import java.sql.SQLException;

import pojos.Book;

public interface IBookDao {
//add a method to insert new book details
	String addNewBook(Book newBook) throws SQLException;
}

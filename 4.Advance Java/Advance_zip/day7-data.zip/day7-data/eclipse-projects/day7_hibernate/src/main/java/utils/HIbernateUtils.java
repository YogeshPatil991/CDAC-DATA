package utils;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class HIbernateUtils {
//provide singleton , immutable SF
	private static SessionFactory factory;
	static {
		System.out.println("in static init block");
		factory = new Configuration().configure().buildSessionFactory();
		System.out.println("SF  created !");
	}
	public static SessionFactory getFactory() {
		return factory;
	}
	
}

package tester;
import static utils.HIbernateUtils.getFactory;
import org.hibernate.*;

public class TestHibernate {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory())
		{
			System.out.println("Hibernate booted !!!!!!!!!!!!");
			System.out.println("SF "+sf);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

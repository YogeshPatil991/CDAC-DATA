package dao;

import java.sql.SQLException;
import java.util.List;

import pojos.Book;

public interface IBookDao {
//add a method to insert new book details
	String addNewBook(Book newBook) throws SQLException;
	//add a method to get all books from db
	List<Book> fetchBooks() throws SQLException;
}

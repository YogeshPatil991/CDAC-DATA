package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojos.Book;
import static utils.DBUtils.getConnection;

public class BookDaoImpl implements IBookDao {
	// state
	private Connection cn;
	private PreparedStatement pst1, pst2;

	// def ctor : will be called by layer above : BookBean (java bean)
	public BookDaoImpl() throws SQLException {
		// get cn from DBUtils
		cn = getConnection();
		pst1 = cn.prepareStatement("insert into books values(default,?,?,?,?)");
		pst2 = cn.prepareStatement("select * from books");
		System.out.println("Book dao created!");
	}

	@Override
	public String addNewBook(Book newBook) throws SQLException {
		// set IN params
		pst1.setString(1, newBook.getTitle());// title
		pst1.setString(2, newBook.getAuthor());// author
		pst1.setString(3, newBook.getCategory());// category
		pst1.setDouble(4, newBook.getPrice());// price
		// exec update : DML
		int updateCount = pst1.executeUpdate();
		if (updateCount == 1)
			return "Book details inserted successfully!";
		return "Insertion of book details failed!!!!!!!!!!!!!!!!!!";

	}

	@Override
	public List<Book> fetchBooks() throws SQLException {
		List<Book> books = new ArrayList<>();
		// exec query
		try (ResultSet rst = pst2.executeQuery()) {
			while (rst.next())
				// bookId, String title, String author, String category, double price
				books.add(new Book(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4),
						rst.getDouble(5)));
		}
		return books;
	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		System.out.println("Book dao cleaned up");
	}

}

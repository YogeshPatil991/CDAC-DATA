package beans;

import java.sql.SQLException;

import dao.UserDaoImpl;
import pojos.User;

public class UserBean {
	//clnt's req params
	private String userName;
	private String password;
	//dependency : user dao
	private UserDaoImpl userDao;
	//save user details
	private User userDetails;
	//mesg
	private String message;
	//ctor 
	public UserBean() throws SQLException{
		//create user dao instance
		userDao=new UserDaoImpl();
		System.out.println("user bean created!");
	}
	//setter / getters
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserDaoImpl getUserDao() {
		return userDao;
	}
	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}
	public User getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(User userDetails) {
		this.userDetails = userDetails;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	//Add a B.L method for user authentication n authorization
	public String validateUser() throws SQLException
	{
		System.out.println("in validate user "+userName+" "+password);
		//invoke dao's method 
		userDetails=userDao.validateUser(userName, password);
		if(userDetails == null)// => invalid login
		{
			message="Invalid Login , Please retry!!!!!!!!!!";
			return "login";
		}
		//=> valid user login 
		message="Login Successful!";
		if(userDetails.getRole().equals("admin"))
			return "admin";
		//=> voter login
		if(userDetails.isStatus())
			return "logout";
		//voter not yet voted
		return "candidate_list";
	}

}

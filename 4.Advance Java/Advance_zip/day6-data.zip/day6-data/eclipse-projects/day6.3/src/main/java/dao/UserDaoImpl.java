package dao;

import static utils.DBUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pojos.User;

public class UserDaoImpl implements IUserDao {
	// state
	private Connection cn;
	private PreparedStatement pst1, pst2;

	public UserDaoImpl() throws SQLException {
		// 1. get cn
		cn = getConnection();
		// pst : select query
		pst1 = cn.prepareStatement("select * from voters where name=? and password=?");
		pst2 = cn.prepareStatement("update voters set status=true where id=?");
		System.out.println("user dao created !");
	}

	@Override
	public User validateUser(String name, String password) throws SQLException {
		// 1. set IN params
		pst1.setString(1, name);
		pst1.setString(2, password);
		// exec query --> RST
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next()) // valid login
				return new User(rst.getInt(1), name, rst.getString(3), password, rst.getBoolean(5), rst.getString(6));
		}
		return null;
	}

	@Override
	public String updateVotingStatus(int voterId) throws SQLException {
		// 1. set IN param : voter id
		pst2.setInt(1, voterId);
		// 2. exec update
		int rowCount = pst2.executeUpdate();
		if (rowCount == 1)
			return "Updated voting status";
		return "Updating voting status failed";
	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		System.out.println("user dao cleaned up !");
	}

}

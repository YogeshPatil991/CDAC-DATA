package dao;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import pojos.Role;
import pojos.User;

public interface IUserDao {
//add a method to insert user details
	String registerUser(User newUser);

	// add a method to insert user details , using getCurrentSession
	String registerUserWithGetCurntSession(User newUser);

	// add a method to get user details by it's id
	User getUserDetailsById(int userId);

	// add a method to fetch all users' details
	List<User> getAllUsers();

	// add a method to get users by some criteria(date n role)
	List<User> getUsersByDateAndRole(LocalDate start, LocalDate end, Role role);

	// add a method to get user names reged under specific role
	List<String> getUserNamesByRole(Role userRole);

	// add a method to get some of the user details (name , email , reg amount , reg
	// date) for users under specific role
	List<User> getUserDetailsByCtorExpr(Role userRole);

	// change password
	String changePassword(String email, String oldPwd, String newPwd);
	
	//bulk update : apply discount for bulk users
	String bulkApplyDiscount(LocalDate date, double discount);
	//un subscribe user
	String unsubscribeUser(int userId);//OR try with  i/p : email : lab work !
	//add a method to store image in db
	String storeImage(String fileName,String userEmail) throws IOException;
	//add a method to restore image from DB
	String restoreImage(String fileName,String userEmail) throws IOException;
	
	
	
}

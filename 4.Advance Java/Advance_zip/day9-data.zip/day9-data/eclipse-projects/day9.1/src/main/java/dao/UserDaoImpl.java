package dao;

import pojos.Role;
import pojos.User;
import static utils.HibernateUtils.getSf;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.hibernate.*;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User newUser) {
		// newUser : transient
		String mesg = "User registration failed!!!!!!!!!";
		// 1. get SF from utils ---> open hib. session
		Session hibSession = getSf().openSession();// Getting s Session from SF : pools out a db conn , L1 cache is
													// created
		Session hibSession2 = getSf().openSession();
		System.out.println(hibSession == hibSession2);// f
		System.out.println("session open " + hibSession.isOpen() + " connected " + hibSession.isConnected());// t t

		// 2. begin tx
		Transaction tx = hibSession.beginTransaction();
		try {
			// API of org.hibernate.Session : public Serializable save(Object
			// transientObject) throws HibernateExc
			hibSession.save(newUser); // transient ---> persistent
			// => success --> commit tx
			tx.commit(); // insert query will be fired
			System.out.println(
					"after commit : session open " + hibSession.isOpen() + " connected " + hibSession.isConnected());// t
																														// t

			mesg = "User registered with ID " + newUser.getUserId();
		} catch (RuntimeException e) {
			// roll back tx
			if (tx != null)
				tx.rollback();
			// re throw the exc to caller
			throw e;
		} finally {
			// close session
			if (hibSession != null)
				hibSession.close();// L1 cache is destroyed , pooled out db cn rets to the pool
		}
		System.out.println(
				"after finally : session open " + hibSession.isOpen() + " connected " + hibSession.isConnected());// t t

		return mesg;
	}

	@Override
	public String registerUserWithGetCurntSession(User newUser) {
		// newUser : TRANSIENT => not yet added to L1 cache , no rec in db , exists ONLY
		// in obj heap
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		Session session2 = getSf().getCurrentSession();
		System.out.println(session == session2);// t
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		System.out.println("session open " + session.isOpen() + " connected " + session.isConnected());// t t
		try {
			session.persist(newUser);// newUser : PERSISTENT (part of L1 cache) , but not yet part of db
			tx.commit(); // hib performs auto dirty checking(session.flush() : synchs up state of L1
							// cache to DB) --insert query
			// session.close --> L1 cache destroyed , pooled out db cn rets to the pool
			System.out
					.println("after commit : session open " + session.isOpen() + " connected " + session.isConnected());// f
																														// f

		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();// no dirty chking(no session.flush()) , session.close => L1 cache destroyed ,
								// pooled out db cn rets to the pool
			System.out.println(
					"after rollback : session open " + session.isOpen() + " connected " + session.isConnected());// f f

			throw e;
		}
		// newUser : DETACHED (detached from L1 cache BUT not from DB)
		return "User registered with ID " + newUser.getUserId();
	}

	@Override
	public User getUserDetailsById(int userId) {
		User user = null;// user : NA
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// Session API : public <T> T get(Class<T> cls , Serializable id)

			user = session.get(User.class, userId);// int ---> Integer ---> Ser.
			// un comment to confirm L1 cache
//			user=session.get(User.class, userId);//int ---> Integer ---> Ser.
//			user=session.get(User.class, userId);//int ---> Integer ---> Ser.
//			user=session.get(User.class, userId);//int ---> Integer ---> Ser.
//			//user : procvided id exists : PERSISTENT
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return user;// user : DETACHED
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = null;
		String jpql = "select u from User u";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).getResultList();
//			users=session.createQuery(jpql, User.class).getResultList();
//			users=session.createQuery(jpql, User.class).getResultList();
//			//users : list of PERSISTENT entities
			tx.commit();// comment this out to understand the prob!!!!!!!!!!!!!!!!!!!!!!
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;// users : list of DETACHED entities
	}

	@Override
	public List<User> getUsersByDateAndRole(LocalDate start, LocalDate end, Role role) {
		List<User> users = null;
		String jpql = "select u from User u where u.regDate between :begin and :end1 and u.userRole=:rl";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("begin", start).setParameter("end1", end)
					.setParameter("rl", role).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;
	}

	@Override
	public List<String> getUserNamesByRole(Role userRole) {
		List<String> names = null;
		String jpql = "select u.name from User u where u.userRole = :role";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			names = session.createQuery(jpql, String.class).setParameter("role", userRole).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return names;
	}

	@Override
	public List<User> getUserDetailsByCtorExpr(Role userRole) {
		List<User> users = null;
		String jpql = "select new pojos.User(name,email,regAmount,regDate) from User u where u.userRole=:role";
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("role", userRole).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;
	}

	@Override
	public String changePassword(String email, String oldPwd, String newPwd) {
		String mesg = "changing pwd failed!!!!!!!!!!!!!!!!";
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		User user = null;
		// 1. Get Session from SF using getCurrentSession
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("em", email).setParameter("pass", oldPwd)
					.getSingleResult();
			// => valid user login
			// user : PERSISTENT
			user.setPassword(newPwd);// modifying state of the PERSISTENT entity
			tx.commit();// hib performs auto dirty chking : session.flush() --->update query --> session
						// closed
			mesg = "Updated password!";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		// user : DETACHED from L1 cache
		user.setPassword("4567890");// If u change the state of detached entity : hib CAN NOT make the changes in
									// db!
		return mesg;
	}

	@Override
	public String bulkApplyDiscount(LocalDate date1, double discount) {
		String mesg = "bulk updating failed !!!!!!!!!!!!!";
		String jpql = "update User u set u.regAmount=u.regAmount-:disc where u.regDate < :date";
		// 1. get session from SF
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			int rowCount = session.createQuery(jpql).setParameter("disc", discount).setParameter("date", date1)
					.executeUpdate();
			tx.commit();
			mesg = "Updated " + rowCount + " users ....";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public String unsubscribeUser(int userId) {
		String mesg = "User details not removed !!!!!!!!!!";
		// 1. get session from SF
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			User user = session.get(User.class, userId);
			if (user != null) {
				// user : PERSISTENT
				session.delete(user);// HIb simply marks the entity for removal , user : REMOVED
				mesg = "removed user details with user name " + user.getName();
			}
			tx.commit(); // auto dirty chking ---> session.flsuh --> delete query fired , -->
							// session.close : L2 cache is destroyed , db cn rets to pool
			// user : TRANSIENT
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	} // user obj is marked for GC : ending java obj life cycle

	@Override
	public String storeImage(String fileName, String userEmail) throws IOException {
		StringBuilder mesg = new StringBuilder("Store Image Status : ");
		String jpql = "select u from User u where u.email=:em";
		// 1. get session from SF
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// 3 validate file
			File file = new File(fileName);
			if (file.isFile() && file.canRead()) {
				// valid file , check if user exists by email
				User user = session.createQuery(jpql, User.class).setParameter("em", userEmail).getSingleResult();
				// => user exists !
				// user : PERSISTENT
				// invoke setImage
				user.setImage(FileUtils.readFileToByteArray(file));
				// mesg : success
				mesg.append("Sucess !");

			} else
				mesg.append("Failed : Invalid file name");

			tx.commit();// update
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg.toString();
	}

	@Override
	public String restoreImage(String fileName, String userEmail) throws IOException {
		String mesg ="ReStoring  Image Failed";
		String jpql = "select u from User u where u.email=:em";
		// 1. get session from SF
		Session session = getSf().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// get persistent user from email
			User user = session.createQuery(jpql, User.class).
					setParameter("em", userEmail).getSingleResult();
			// => user exists !
			// user : PERSISTENT
			// read byte[] from DB (BLOB) --> bin file
			FileUtils.writeByteArrayToFile(new File(fileName), user.getImage());
			mesg="Restored image for user with ID "+user.getUserId();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}

package tester;

import static utils.HibernateUtils.getSf;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;

public class BulkUpdate {

	public static void main(String[] args) {
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			// create hib dao instance
			UserDaoImpl dao = new UserDaoImpl();
			System.out.println("Enter reg date n  discount");
			System.out.println(dao.bulkApplyDiscount(LocalDate.parse(sc.next()), sc.nextDouble()));
		} // JVM : sf.close() => conn pool : cleaned up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

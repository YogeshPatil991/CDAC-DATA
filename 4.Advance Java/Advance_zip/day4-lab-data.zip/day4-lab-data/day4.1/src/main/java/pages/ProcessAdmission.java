package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojos.Student;

/**
 * Servlet implementation class ProcessAdmission
 */
@WebServlet("/admission")
public class ProcessAdmission extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final double MIN_SCORE;
	static {
		MIN_SCORE = 75;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in do-post of " + getClass()+" invoked by "+Thread.currentThread().getName());
		// set cont type
		// response.setContentType("text/html");
		// try(PrintWriter pw=response.getWriter())
		// {
		// get student details from req params
		String fName = request.getParameter("first_name");
		String lName = request.getParameter("last_name");
		double testScore = Double.parseDouble(request.getParameter("score"));
		String courseName = request.getParameter("course");
		// create stident object wrapping all the details
		Student newStudent = new Student(fName, lName, testScore, courseName);
		// checking for the admission
		if (testScore > MIN_SCORE)
			newStudent.setAdmitted(true);
		// test this
		// pw.print("from the 1st page....");
//			pw.flush();
		// store student dtls : under current request scope
		// setAttribute
		request.setAttribute("student_dtls", newStudent);// when will this attribute(obj) be marked for GC ? after resp
															// is rendered
		// Navigate the clnt to the results page in the SAME requrest : using Req
		// dispatching tech.
		// Steps 1. Create RD object
		RequestDispatcher rd = request.getRequestDispatcher("result");
		System.out.println("rd 's class "+rd.getClass());// imple class name : catatlina pkg
		// 2. forward the clnt to the next page
		rd.forward(request, response);
		// WC : clears resp buffer ---suspends curnt method exec --invokes Result pages'
		// doPost ---after exec (resp generation) --> control comes back --method rets
		System.out.println("control came back .....");

		// }
	}

}

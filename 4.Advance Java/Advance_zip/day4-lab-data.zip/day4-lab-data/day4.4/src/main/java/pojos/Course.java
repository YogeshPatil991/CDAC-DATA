package pojos;

public enum Course {
	JAVA(80), HTML(70), MERN(85), DBT(75), ANGULAR(78);
	private double minScore;

	private Course(double minScore) {
		this.minScore = minScore;
	}

	public double getMinScore() {
		return minScore;
	}	
}

package utils;

import java.sql.*;

public class DBUtils {
//add a static method to get FIXED db conn
	private static Connection connection;

	public static void openConnection(String dbURL,String userName,String pwd) throws SQLException {
		
		connection = DriverManager.getConnection(dbURL,userName,pwd);

	}
	

	public static Connection getConnection() {
		return connection;
	}


	// add a static method to close the connection
	public static void closeConnection() throws SQLException {
		if (connection != null)
			connection.close();
	}
}

import '../assets/common.css'
function Footer()
{
    return <div className='footer'>
                <h1>This is Footer</h1>
            </div>
}

export default Footer;
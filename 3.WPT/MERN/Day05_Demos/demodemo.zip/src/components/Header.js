import '../assets/common.css'
function Header()
{
    return <div className='header'>
                <h1>This is header</h1>
            </div>
}

export default Header;
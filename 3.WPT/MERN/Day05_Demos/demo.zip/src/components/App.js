import { Component } from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';

class App extends Component
{
  render()
  {
    return <table className='table table-bordered'>
            <tr>
              <td>1</td>
              <td>mahesh</td>
            </tr>
            <tr>
              <td>1</td>
              <td>mahesh</td>
            </tr>

            <tr>
              <td>1</td>
              <td>mahesh</td>
            </tr>

            <tr>
              <td>1</td>
              <td>mahesh</td>
            </tr>
          </table>;
  }
}




// import '../node_modules/bootstrap/dist/css/bootstrap.css';

// function App() //App - Functional Component
// {
//   return <h1 className='btn-success'>Welcome Home</h1>;
// }



// import './common.css';
// function App() 
// {
//   return <h1 className='AStyle'>Welcome Home</h1>;
// }

export default App;

// function About() 
// {
//   return <h1>About Us</h1>;
// }

// export {App, About};

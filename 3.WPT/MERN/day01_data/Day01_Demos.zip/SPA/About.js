
//About Class Component
class About
{
    render(){
        return `<h1>About Us</h1>`;
    }
}

//Home Functional Component
function Home()
{
    return `<h1>Welcome to Home</h1>`;
}


//Contact Functional Component
function Contact()
{
    return `<h1>Contact Us</h1>`;
}
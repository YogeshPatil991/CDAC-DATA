const SayHi =  require('./Sunbeam');

SayHi("mahesh");




// const somethingExported =  require('./Sunbeam');

// somethingExported("mahesh");
// // console.log(somethingExported);
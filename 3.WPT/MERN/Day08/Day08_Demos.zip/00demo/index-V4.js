const somethingExported = require('os');

console.log(somethingExported);
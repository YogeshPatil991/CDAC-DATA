// const somethingExported =  require('./Infosys');

// somethingExported.GoodEvening();

// var obj = new somethingExported.Employee();
// obj.Print();

// console.log(somethingExported.interestRate);

// console.log(somethingExported.mathObject.Add(10,20))

// console.log(somethingExported);
// somethingExported.SayHello();




function SayHi(name)
{
    console.log("Hi " + name);
}

module.exports = SayHi;
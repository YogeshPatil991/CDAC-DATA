function Footer()
{
    return <h1>This is Footer!</h1>
}

export default Footer;
function NotFound()
{
    return <h1>The resource you are looking for does not exist!</h1>
}

export default NotFound;
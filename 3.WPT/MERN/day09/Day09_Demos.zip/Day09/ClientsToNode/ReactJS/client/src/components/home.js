function Home()
{
    return <h1>Welcome Home</h1>
}

export default Home;
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = 
  ReactDOM.createRoot(document.getElementById('mainContainer'));

  root.render(<App/>);

  // root.render(App());

  // var obj = new App();
  // root.render(obj.render());
